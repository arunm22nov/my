import React, { useState } from "react";
import ReactDOM from 'react-dom';
import './index.css';
import app from './css/app.css';
import App from './App';
import "jquery";
import "popper.js/dist/umd/popper";
import "bootstrap/dist/js/bootstrap"; 
import "bootstrap/dist/css/bootstrap.css";
import reportWebVitals from './reportWebVitals';

   

ReactDOM.render(

  <>

    <App />

  </>,

  document.getElementById('root')

);

reportWebVitals();
