import React, { useState, useEffect } from 'react';
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Switch, Route, Redirect, Link } from "react-router-dom";
import { createBrowserHistory } from 'history';
import Login from './components/Login/Login';
import Operator from './components/Operator/Operator';
import Manager from './components/Manager/Manager';
import Admin from "./components/Admin/Admin";



const App = () => (
  
  <Router history={createBrowserHistory}>

 

    <Switch>

    

          <Route exact path='/' component={Login} />

          <Route  path='/manager' component={Manager} />

          

          <Route  path='/operator' component={Operator} />
          

          <Route  path='/admin' component={Admin} />
          

          {/* <PrivateRoute authed={this.state.authed} path='/login' component={Admin} /> */}

          

   

    </Switch>

  </Router>
  
);

const rootElement = document.getElementById("root");
ReactDOM.render(<App />, rootElement);

export default App;