import $ from 'jquery/src/jquery';


const formFunction = (default_json) => {
    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.
    var jQueryScript = document.createElement('script');
    jQueryScript.setAttribute('src', 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
    document.head.appendChild(jQueryScript);

    $(document).ready(function () {
        var form_count = -1;
        while (true) {
            form_count = form_count + 1;
            if (("form" + form_count) in default_json) {
                if (form_count != 0) {
                    document.getElementById("addform").click();
                }

            } else {
                form_count = form_count - 1;
                break;
            }
        }


        for (var count = 0; count <= form_count; count++) {
            document.getElementById("pay_stamp" + count).value = default_json['form' +count].pay_stamp            
                document.getElementById("paykind_code1" + count).value = default_json['form' +count].paykind_code1
                document.getElementById("paykind_code2" + count).value = default_json['form' +count].paykind_code2
                document.getElementById("paykind_code3" + count).value = default_json['form' +count].paykind_code3
                document.getElementById("valid1" + count).value = default_json['form' +count].valid
                document.getElementById("valid2" + count).value = default_json['form' +count].valid2
                document.getElementById("sub" + count).value = default_json['form' +count].sub
                document.getElementById("servicestate" + count).value = default_json['form' +count].servicestate
                document.getElementById("claimnumber" + count).value = default_json['form' +count].claimnumber
                document.getElementById("invoiceno" + count).value = default_json['form' +count].invoiceno
                document.getElementById("firstname" + count).value = default_json['form' +count].firstname
                document.getElementById("lastname" + count).value = default_json['form' +count].lastname
                document.getElementById("specialinstructions1" + count).value = default_json['form' +count].specialinstructions1
                document.getElementById("specialinstructions2" + count).value = default_json['form' +count].specialinstructions2
                document.getElementById("closeclaim" + count).value = default_json['form' +count].closeclaim
                document.getElementById("payableamount1" + count).value = default_json['form' +count].payableamount1
                document.getElementById("payableamount2" + count).value = default_json['form' +count].payableamount2
                document.getElementById("dateofservice1" + count).value = default_json['form' +count].dateofservice1
                document.getElementById("dateofservice2" + count).value = default_json['form' +count].dateofservice2
                document.getElementById("taxid" + count).value = default_json['form' +count].taxid
                document.getElementById("payeename" + count).value = default_json['form' +count].payeename
                document.getElementById("mailtoname" + count).value = default_json['form' +count].mailtoname
                document.getElementById("address1" + count).value = default_json['form' +count].address1
                document.getElementById("address2" + count).value = default_json['form' +count].address2
                document.getElementById("cityname" + count).value = default_json['form' +count].cityname
                document.getElementById("zipcode" + count).value = default_json['form' +count].zipcode
                document.getElementById("state" + count).value = default_json['form' +count].state
                document.getElementById("PageNo" + count).value = default_json['form' +count].PageNo
                document.getElementById("natureofpayment" + count).value = default_json['form' +count].natureofpayment
                document.getElementById("taxable" + count).value = default_json['form' +count].taxable
                document.getElementById("taxableto" + count).value = default_json['form' +count].taxableto
                document.getElementById("mcsc" + count).value = default_json['form' +count].mcsc
                document.getElementById("settlement_code1" + count).value = default_json['form' +count].settlementCodePaykindCode1
                document.getElementById("settlement_code2" + count).value = default_json['form' +count].settlementCodePaykindCode2
      
        }
        document.getElementById("pay_stamp0").focus();

    });
}


export default formFunction;
