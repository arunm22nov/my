import React, { useCallback, useMemo } from 'react';
import { forwardRef, useState, useImperativeHandle, useRef } from "react";
import { AgGridReact } from 'ag-grid-react';
import { Link } from 'react-router-dom';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

const Table = forwardRef(({ onSelectRow }, ref) => {
  const gridRef = useRef();
  const containerStyle = useMemo(() => ({ width: '100%', height: '100%' }), []);
  const gridStyle = useMemo(() => ({ height: '500px', overflow: 'scroll', width: '100%', margin: '33px 0px 0px 0px' }), []);
  const [rowData, setRowData] = useState();
  const [selectedFiles, setSelectedFiles] = useState([]);
  var defaultFilterParams = { readOnly: true };

  useImperativeHandle(ref, () => ({
    onGridReady,
  }));

  const LinkCellRenderer = (params) => (
    // <Link to={"/edit/" + params.data.id}>Edit</Link>
    <Link to={{ pathname: `/operator/Operatorvalidate`, state: { file: params.data.case_id } }}>{params.data.case_id}</Link>
  );

  const onCellClicked = useCallback((event) => {
    if (event.colDef.field == "case_id") {
      localStorage.setItem("pdfName", "yes");
    }
    
  });


  const [columnDefs, setColumnDefs] = useState([

    {
      headerName: 'CAIDSE ', field: 'case_id', hide: false,
      //cellRenderer: 'agGroupCellRenderer', 
      cellRenderer: LinkCellRenderer,
      // headerCheckboxSelection: true,
      // headerCheckboxSelectionFilteredOnly: true,
      //checkboxSelection: true,
      filter: 'agTextColumnFilter',
      onCellClicked: onCellClicked,
      filterParams: {
        applyMiniFilterWhileTyping: true,
      }, sortable: true
      // , cellRendererParams: { checkbox:true},
    },
    {
      headerName: 'LOB', field: 'lob', hide: false, filter: 'agTextColumnFilter', filterParams: {
        applyMiniFilterWhileTyping: true,
      }, sortable: true
    },
    //  { headerName: 'CASE ID', field: 'case_id', hide: false },
    {
      headerName: 'CREATION DATE', field: 'creation_date', hide: false, filter: 'agTextColumnFilter', filterParams: {
        applyMiniFilterWhileTyping: true,
      }, sortable: true
    },
    {
      headerName: 'STATUS', field: 'status', hide: false, filter: 'agTextColumnFilter', filterParams: {
        applyMiniFilterWhileTyping: true,
      }, sortable: true
    },
    {
      headerName: 'ASSIGNED ON', field: 'assigned_date', hide: false, filter: 'agTextColumnFilter', supressMenu: true, filterParams: {
        applyMiniFilterWhileTyping: true,
      }, sortable: true
    },

    {
      headerName: 'PRIORITY', field: 'priority', hide: false, filter: 'agTextColumnFilter', supressMenu: true, filterParams: {
        applyMiniFilterWhileTyping: true,
      }, sortable: true
    },

    { headerName: 'ID', field: 'id', hide: true }
  ]);
  const defaultColDef = useMemo(() => {
    return {
      flex: 1,
      minWidth: 100,
      floatingFilter: true,
      filter: true
    };
  }, []);
  const autoGroupColumnDef = useMemo(() => {

    return {
      headerName: 'ID',
      field: 'id',

      minWidth: 250,
      cellRenderer: 'agGroupCellRenderer',
      cellRendererParams: {
        checkbox: true,
      },
    };
  }, []);



  const onGridReady = useCallback((params) => {
    console.log("operator to table")
    if ("data" in params) {
      let row_data = [];
      let table_data = params.data.file_list.files_list;
      row_data = table_data.map((file) => {
        let priority = "";
        let lob = "";
        if (file.lob.lob_name.toLowerCase() == "rcs") {
          lob = file.lob.lob_name.toUpperCase();
        } else {
          lob = file.lob.lob_name;
        }
        if (file.is_on_priority) {
          priority = "Rush";
        } else {
          priority = "Normal";
        }
        return {
          id: file.id,
          case_id: file.case_id,
          status: file.status,
          assigned_date: file.assigned_date,
          creation_date: file.creation_date,
          lob: lob,
          priority: priority
        }
      });
      setRowData(row_data);
    }



  });


  const onQuickFilterChanged = useCallback(() => {
    gridRef.current.api.setQuickFilter(
      document.getElementById('quickFilter').value
    );
  }, []);

  const onSelectionChanged = useCallback((event) => {
    let temp = []

    for (let i = 0; i < event.api.getSelectedNodes().length; i++) {
      temp.push(event.api.getSelectedNodes()[i].data);
    }
    onSelectRow(temp);
    //console.log(temp)
    //onsole.log(selectedFiles)
  }, [onSelectRow]);






  return (
    <div style={containerStyle}>
      <div className="example-wrapper">
        <div className="quick-filter" style={{ marginBottom: '5px' }}>
          <input
            type="text"
            onInput={onQuickFilterChanged}
            id="quickFilter"
            placeholder="Quick filter"
          />
        </div>

        <div style={gridStyle} className="ag-theme-alpine">
          <AgGridReact
            frameworkComponents={{
              LinkCellRenderer
            }}
            ref={gridRef}
            rowData={rowData}
            columnDefs={columnDefs}
            defaultColDef={defaultColDef}
            suppressRowClickSelection={true}
            onGridReady={onGridReady}
            onSelectionChanged={onSelectionChanged}
            rowSelection={'multiple'}
            enableCellTextSelection={true}
            pagination={true}
            paginationPageSize={10}
            // onCellClicked={onCellClicked}
          ></AgGridReact>
        </div>
      </div>
    </div>
  );
});

export default Table;