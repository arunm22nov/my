import { Worker } from '@react-pdf-viewer/core';

// Import the main component
import { Viewer } from '@react-pdf-viewer/core';

// Import the styles
import '@react-pdf-viewer/core/lib/styles/index.css';
// import { defaultLayoutPlugin } from '@react-pdf-viewer/default-layout';
import { ProgressBar } from '@react-pdf-viewer/core';
import { SelectionMode } from '@react-pdf-viewer/selection-mode';
import { toolbarPlugin } from '@react-pdf-viewer/toolbar';


// Your render function

const MyComponent = ({url}) => {
  // const defaultLayoutPluginInstance = defaultLayoutPlugin();
 

  const toolbarPluginInstance = toolbarPlugin({
    getFilePlugin: {
        fileNameGenerator: (file) => {
            const fileName = file.name.substring(file.name.lastIndexOf('/') + 1);
            return `a-copy-of-${fileName}`;
        }
    },
    // searchPlugin: {
    //     keyword: 'PDF'
    // },
    selectionModePlugin: {
        selectionMode: SelectionMode.Text
    },
});
const { Toolbar } = toolbarPluginInstance;



 

  return (
    <Worker workerUrl="https://unpkg.com/pdfjs-dist@2.13.216/build/pdf.worker.min.js">
      <Toolbar/>
<Viewer plugins={[
                toolbarPluginInstance,
            ]}
            fileUrl="http://localhost:8000/_1340149920.pdf" 
            renderLoader={(percentages) => (
              <div style={{ width: '240px' }}>
                  <ProgressBar progress={Math.round(percentages)} />
              </div>
          )}
          />;
    ...
</Worker>
  );
};

export default MyComponent;


// import { pdfjs } from 'react-pdf';
// import React, { useState } from 'react';
// import { Document, Page } from 'react-pdf';
// pdfjs.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjs.version}/pdf.worker.min.js`;


// const MyComponent = ({url}) => {
//   const [numPages, setNumPages] = useState(null);
//   const [pageNumber, setPageNumber] = useState(1);

//   function onDocumentLoadSuccess({ numPages }) {
//     setNumPages(numPages);
//     removeTextLayerOffset();
//   }
//  function onLoadError(error) {
//    console.log(error);
//  }

//  function onSourceError(error) {
//    console.log(error);
//  }

//  function removeTextLayerOffset() {
//   const textLayers = document.querySelectorAll('.react-pdf__Page__textContent');
//   textLayers.forEach((layer) => {
//     const { style } = layer;
//     style.display = 'none';
//   });
// }

//   return (
//     <div>
//       <Document
//         file="http://localhost:8000/expense/_1340049686.pdf"
//         onLoadSuccess={onDocumentLoadSuccess}
//         onLoadError={onLoadError}
//         onSourceError={onSourceError}
//       >
//         {[...Array(numPages).keys()].map((p) => (
//           <Page pageNumber={p + 1} />
//         ))}
//       </Document>
//     </div>
//   );
// };

// export default MyComponent;




// // import { useState, useEffect, useRef } from "react";
// // import WebViewer from '@pdftron/pdfjs-express-viewer';



// // const MyComponent = (documentLink) => {
// //   const viewer = useRef(null);

// //   useEffect(() => {
// //     WebViewer(
// //       {
        
// //         initialDoc: documentLink,
// // 		licenseKey: 'VMeLR5MsW5lX3X9YfqQF',
// //       },
// //       viewer.current,
// //     ).then((instance) => {
// //         // now you can access APIs through the WebViewer instance
// //         const { Core } = instance;

// //         // adding an event listener for when a document is loaded
// //         Core.documentViewer.addEventListener('documentLoaded', () => {
// //           console.log('document loaded');
// //         });

// //         // adding an event listener for when the page number has changed
// //         Core.documentViewer.addEventListener('pageNumberUpdated', (pageNumber) => {
// //           console.log(`Page number is: ${pageNumber}`);
// //         });
// //       });
// //     }, []);

// //   return (
// //     <div className="MyComponent">      
// //       <div className="webviewer" style={{height:860}} ref={viewer}></div>
// //     </div>
// //   );
// // };

// export default MyComponent;
