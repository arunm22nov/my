import React, { useState, useEffect, useRef } from 'react';
import Table from './table';
import 'react-toastify/dist/ReactToastify.min.css';
import { getUser, removedUserSession, getUserSession } from "../Utils/common";




export default function OperatorLanding(props) {
	const session = getUserSession()
	if (session == null) {
		props.history.push('/');
	}
	// console.log("Session : " + session)
	const childRef = useRef(null);
	const [open, setOpen] = useState(false);
	const user = getUser();
	const handleLogout = () => {
		removedUserSession();
		props.history.push('/');
	}
	const [assigned, setAssigned] = useState('');
	const [completed, setCompleted] = useState('');
	const [error, setError] = useState(null);
	const [loading, setLoading] = useState(false);
	const [userId, setUserId] = useState('');
	async function fetchData() {
		// console.log(getUserSession())
		const response = await fetch(process.env.REACT_APP_API_URL + "/api/operator_files_info/", {
			method: "GET",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			}
		}).then(response => response.json())
			.then(data => {
				setAssigned(data.data.files_status.assigned)
				setCompleted(data.data.files_status.completed)
				childRef.current.onGridReady(data);


			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				setLoading(false);
				if (error.response.status === 401 || error.response.status === 400) {
					setError(error.response.data.message);
				}
				else {
					setError("error message");
				}
			});


	}
	useEffect(() => {
		fetchData();
	}, []);

	return (

		<div className="section-code">
			<div className="row">
				<div className="col-md-12">
					<h1>Welcome {user}! <a href="" type="link" className="logout" onClick={handleLogout}>Logout</a></h1>
				</div>

			</div>
			<div className="col-md-12 row d-flex">
				<div className="white-bg">
					<Table ref={childRef} />
				</div>
				<div class="clear"></div>
			</div>
		</div>



	)
}

