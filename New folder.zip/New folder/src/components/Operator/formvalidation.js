export const formvalidation = (paykind_code1, paykind_code2, paykind_code3, valid, sub, servicestate, claimnumber, invoiceno, firstname, lastname, specialinstructions, closeclaim, payableamount, dateofservice1, dateofservice2, taxid, payeename, address1, address2, cityname, zipcode, state, natureofpayment, taxable, taxableto, mcse, page)=>{
  let  validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  let  phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
  let  numaricRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
  let  alphanumaricRegex = /^[a-zA-Z0-9_]*$/;
  let  alphaRegex = /^[A-Z]+$/im;
//   if (!email.match(validRegex)) {
//       return {error: true, message:  " Invalid email"};
//   }
   if (!payableamount.match(numaricRegex)) {
      return {error: true, message:  "Enter Total payable amount of the claim in Numaric only "};
  }
  else if (!paykind_code1.match(numaricRegex)) { 
      return {error: true, message:  " Enter Paykind code in Numaric only"};
  }
  else if (!paykind_code2.match(numaricRegex)) { 
    return {error: true, message:  " Enter Paykind code in Numaric only"};
}
else if (!paykind_code3.match(numaricRegex)) { 
    return {error: true, message:  " Enter Paykind code in Numaric only"};
}
else if (!valid.match(numaricRegex)) { 
    return {error: true, message:  " Enter Val ID in Numaric only"};
}
//   else if (role != 1 && role != 2 && role != 3) {
//       return {error: true, message:  " Please select role"};
//   }
//   else if (page == "addUser" && password.length < 5) {
//       return {error: true, message:  "Password should be atleast 5 characters long"};
//   }
//   else if (lob.length < 1) {
//       return {error: true, message:  " Please select atleast 1 LOB"};
//   }
//   else if (!contact_number.match(phoneRegex)) {
//       return {error: true, message:  " Invalid contact number"};
//   }
  else {
      return {error: false, message:  ""};
  }

 }

 