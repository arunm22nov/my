import React, { useState } from "react";
import Form from "react-bootstrap/Form";
import Button from "react-bootstrap/Button";
import axios from 'axios';
import { getToken, getUser, removedUserSession, showToaster, setUserSession, getUserSession } from "../Utils/common";
import logoexl from '../../images/exl-logo.png';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import { Modal } from 'react-bootstrap';
// import { Construction } from "@mui/icons-material";



const Login = (props) => {
	const [username, setUsername] = useState('');
	const [password, setPassword] = useState('');
	const [error, setError] = useState(null);
	const [newpassword, setNewpassword] = useState('');	
	const [currentpassword, setCurrentpassword] = useState('');	
	const [show1, setShow1] = useState(false);
	const handleClose1 = () => {
		setShow1(false)
		setNewpassword('');
		setCurrentpassword('');
		setConfirmPassword('');
	}

	const handleShow1 = () => setShow1(true);
	const [loading, setLoading] = useState(false);
	const [confirmPassword, setConfirmPassword] = useState("");
	// console.log(process.env)

	let config = {
		headers: {
			"Access-Control-Allow-Origin": "*",
		}
	}
	axios.defaults.headers["content-type"] = "application/json";
	axios.defaults.headers["Access-Control-Allow-Origin"] = "*";
	
	const [errorMessage, setErrorMessage] = React.useState("");
	const handleLogin = async () => {
		// console.log(process.env.API_URL)
		const response = await fetch(process.env.REACT_APP_API_URL+"/api/login/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				// "Access-Control-Allow-Headers": "*",
				// "Access-Control-Allow-Methods": "*",
				// "Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false
				//"Authorization" : "Bearer " + getUserSession().access
			},
			body: JSON.stringify({
				"data": {
					username: username,
					password: password

				}
			})
		}).then(response => response.json())
			.then(data => {
				// console.log("response")
				// console.log(data)
				setLoading(false);
				if (data.error == true) {
					showToaster(data.message, 'error')
				}
				else {
					setUserSession(JSON.stringify(data.data.token), data.data.user)
					if (data.data.user.is_admin === true) {
						props.history.push('/admin');
					}
					else if (data.data.user.is_admin === false && data.data.user.is_manager === true) {
						props.history.push('/manager');
					}
					else {
						props.history.push('/operator');
					}
				}
			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				setLoading(false);
				if (error.response.status === 401 || error.response.status === 400) {
					setError(error.response.data.message);
				}
				else {
					setError("error message");
				}
			});


	}

	
	const handleRestpassword = async () => {
		if (username.length < 1) {
			showToaster("User ID cannot be empty", "info")
			return
		}
		if (newpassword != confirmPassword) {
			showToaster("Passwords do not match ", "info")
			return
		}
		if (newpassword.length < 5) {
			showToaster("Password should contain minimum 5 characters ", "info")
			return
		}

		const response = await fetch(process.env.REACT_APP_API_URL+"/api/reset_password/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				// "Access-Control-Allow-Headers": "*",
				// "Access-Control-Allow-Methods": "*",
				// "Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false
				//"Authorization" : "Bearer " + getUserSession().access
			},
			body: JSON.stringify({
				"data": {
					username: username,
					current_password: currentpassword,
					new_password: newpassword

				}
			})
		}).then(response => response.json())
			.then(data => {
				// console.log("response")
				// console.log(data)
				setLoading(false);
				if (data.error == true) {
					showToaster(data.message, 'error')
				}
				else {
					showToaster(data.message, 'success');
					setCurrentpassword("");
					setNewpassword("");
					setConfirmPassword("");
					handleClose1();
				}

			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				setLoading(false);
				if (error.response.status === 401 || error.response.status === 400) {
					setError(error.response.data.message);
				}
				else {
					setError("error message");
				}
			});


	}

	return (
		<div className="App bg_image  py-9"  >
			<div className="maincontainer">
				<div className="container-fluid">
					<div className="row no-gutter">
						<div className="col-md-12"><img className="logo-exl" src={logoexl} /></div>
					</div>
					<div className="row no-gutter">
						<div className="offset-md-4 col-md-4 bg-light login-form">
							<div className="  d-flex align-items-center">
								<div className="col-md-12">
									<div className="row">
										<div className="col-md-12 col-lg-12 col-xl-12 ">
											<div className="logo"></div>
											<div className="Login">
												{errorMessage && <p className="error">{errorMessage}</p>}
												<Form autocomplete="off">
													<Form.Group size="lg" controlId="User Id">
														<Form.Label>User Id</Form.Label>

														<Form.Control autoFocus type="text" value={username} onChange={e => setUsername(e.target.value)} />
													</Form.Group>
													<Form.Group size="lg" controlId="password">
														<Form.Label>Password</Form.Label>
														<Form.Control type="password" value={password} onChange={e => setPassword(e.target.value)} />
													</Form.Group>
													<div className="custom-control custom-checkbox mb-12 py-2">
														
														<Button className="linksec" variant="link" onClick={handleShow1}>Reset password</Button>
													</div>
													<input className="btn btn-submit" type="button"
														value={loading ? "Loading..." : "Login"}
														disabled={loading}
														onClick={handleLogin} />
												</Form>
												<Modal show={show1} onHide={handleClose1}>
													<Modal.Header closeButton>
														Reset Password
													</Modal.Header>
													<Modal.Body className="row py-3"><Form.Group size="lg" className="col-md-6" controlId="User Id">
														<Form.Label>User Id</Form.Label>

														<Form.Control autoFocus type="text" value={username} onChange={e => setUsername(e.target.value)} />
													</Form.Group>
														<Form.Group size="lg" className="col-md-6" controlId="currentpassword">
															<Form.Label>Current Password</Form.Label>
															<Form.Control autocomplete="random-string" type="password" value={currentpassword} onChange={e => setCurrentpassword(e.target.value)} />
														</Form.Group>
														<Form.Group size="lg" className="col-md-6" controlId="password">
															<Form.Label>New Password</Form.Label>
															<Form.Control autocomplete="random-string" type="password" value={newpassword} onChange={e => setNewpassword(e.target.value)} />
														</Form.Group>
														<Form.Group size="lg" className="col-md-6" controlId="password">
															<Form.Label>Confirm Password</Form.Label>
															<Form.Control autocomplete="off" type="password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} />
														</Form.Group>
													</Modal.Body>
													<Modal.Footer >

														<Button variant="warning" onClick={() => handleRestpassword("Reset Password")}>
															Submit
														</Button>
													</Modal.Footer>
												</Modal>
												
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<ToastContainer
				position="top-center"
				autoClose={5000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
				theme='colored'
			/>
		</div>
	);
}

export default Login;