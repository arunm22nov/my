export const addUserValidations = (email, first_name, last_name, username, role, password, lob, contact_number, page)=>{
    //let  validRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    let validRegex = /^([a-zA-Z0-9_\-\.]+)@([a-zA-Z0-9_\-\.]+)\.([a-zA-Z]{2,5})$/;
    let name = /^[A-Za-z ]+$/;
    let phoneRegex = /^[\+]?[(]?[0-9]{3}[)]?[-\s\.]?[0-9]{3}[-\s\.]?[0-9]{4,6}$/im;
   
     if (!first_name.match(name) && !first_name.length < 3) {
        return {error: true, message:  "Invalid name"};
    }
    else if (!last_name.match(name) && !last_name.length < 3) {
        return {error: true, message:  " Invalid Last name"};
    }
    else if (username.length < 1) { // match with ZNA  userid format
        return {error: true, message:  " Invalid user ID"};
    }
    else if (lob.length < 1) {
        return {error: true, message:  " Please select atleast 1 LOB"};
    }
    else if (role != 1 && role != 2 && role != 3) {
        return {error: true, message:  " Please select role"};
    }      
    else if (!contact_number == "" &&!contact_number.match(phoneRegex)) {
        return {error: true, message:  " Invalid contact number"};
    }
    else if (!email == "" &&!email.match(validRegex)) {
        return {error: true, message:  " Invalid email"};
    }
    else if (page == "addUser" && password.length < 5) {
        return {error: true, message:  "Password should be atleast 5 characters long"};
    } 
    else {
        return {error: false, message:  ""};
    }

   }

   