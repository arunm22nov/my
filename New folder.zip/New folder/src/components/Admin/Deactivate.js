import React, { useState, useEffect } from 'react';
import { getToken, getUser, removedUserSession, setUserSession, showToaster, getUserSession, setPost, Post } from "../Utils/common";
import { Col, Form } from 'react-bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';

const Deactivate = (props) => {
	const session = getUserSession()
	if (session == null) {
		props.history.push('/');
	}
	// console.log("Session : " + session)
	const [email, setEmail] = useState('');
	const [first_name, setFirst_name] = useState('');
	const [username, setUsername] = useState('');
	const [last_name, setLast_name] = useState('');
	const [password, setPassword] = useState('');
	const [role, setRole] = useState('');
	const [contact_number, setContact_number] = useState('');
	const [post, getPost] = useState([]);
	const [error, setError] = useState(null);
	const [loading, setLoading] = useState(false);
	const [lob, setLob] = useState('');
	const [is_admin, setIsAdmin] = useState(0);
	const [is_manager, setIsmanager] = useState(0);
	const [userId, setUserId] = useState('');
	const [successMessage, setSuccessMessage] = React.useState("");

	let [users, setUsers] = useState([]);

	const currentUser = ((selectedUser) => {
		
		for (let i = 0; i < users.length; i++) {
			if (users[i].id == selectedUser) {
				// set fields
				setFirst_name(users[i].first_name);
				setLast_name(users[i].last_name);
				setUsername(users[i].username);
				setPassword(users[i].password);
				setEmail(users[i].email);
				setContact_number(users[i].contact_number);
				let lobs = [];
				// for (let j = 0; j < users[i].lob.length; j++) {
				// 	lobs.push(users[i].lob[j].lob_name);
				// }
				// setLob(lobs);
				for (let j = 0; j < users[i].lob.length; j++) {
					if (users[i].lob[j].lob_name.toLowerCase() == "expense") {
                        document.getElementById("expensechkbox").checked = 1;
					} else if(users[i].lob[j].lob_name.toLowerCase() == "rcs") {
						document.getElementById("rcschkbox").checked = 1;
					} else if(users[i].lob[j].lob_name.toLowerCase() == "indemnity") {
						document.getElementById("indemnitychkbox").checked = 1;
					}
					
				}
				if (users[i].is_admin == true) {
					setRole("1");
				} else if (users[i].is_manager == true) {
					setRole("2");
				} else {
					setRole("3");
				}
				break;

			}
		}
		setUserId(selectedUser)
	});
	const handleDeactivate = async () => {

		if (userId == "") {
			showToaster("Please select a user.", "info")
			return;
		}

		if (role == 1) {
			setIsAdmin(1);
			setIsmanager(0);
		} else if (role == 2) {
			setIsAdmin(0);
			setIsmanager(1);
		} else {
			setIsAdmin(0);
			setIsmanager(0);
		}
		const response = await fetch(process.env.REACT_APP_API_URL + "/api/users/", {
			method: "PUT",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			body: JSON.stringify(
				{
					"user": {
						id: userId,
						is_active: 0
					}
				}

			)
		}).then(response => response.json())
			.then(data => {
				fetchData();
				if (data.error == true) {
					showToaster(data.message, 'error')
				}
				else {
					// setSuccessMessage(data.message)
					showToaster(data.message, 'success');
					setEmail("");
					setFirst_name("");
					setUsername("");
					setLast_name("");
					setRole("");
					setLob("");
					setPassword("");
					setContact_number("");

					document.getElementById("expensechkbox").checked = 0;
					document.getElementById("rcschkbox").checked = 0;
					document.getElementById("indemnitychkbox").checked = 0;
				}

			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				showToaster('Something went wrong', 'error')
			});


	}

	async function fetchData() {
		// console.log("inside user effect")
		const response = await fetch(process.env.REACT_APP_API_URL + "/api/users/", {
			method: "GET",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			}
		}).then(response => response.json())
			.then(data => {
				var active_users = [];
				for (var i = 0; i < data.data.length; i++) {
					if (data.data[i].is_active) {
						active_users.push(data.data[i])
					}
				}
				// console.log("response")
				// console.log(data)
				//users = data.data;
				setUsers(active_users)
				// console.log(users);
				setLoading(false);



			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				setLoading(false);
				if (error.response.status === 401 || error.response.status === 400) {
					setError(error.response.data.message);
				}
				else {
					setError("error message");
				}
			});
	}

	useEffect(() => {
		fetchData();
	}, []);


	return (
		<div className="col-md-12  user-details">
			<h2>Deactivate User</h2>
			<div className="row select-user">
				{successMessage && <div className="success"> {successMessage} </div>}
				<div className="col-md-12 ">
					<div className="row d-flex">
						<div className="col-md-12">
							<label className='col-md-3'>Select Name or User ID</label>
							<div className="col-md-6 display-inline">
								<select class="form-select" value={userId} id="disabledSelect" onChange={e => currentUser(e.target.value)}>
									<option hidden> Select user</option>
									{users.map((user) => (
										<option value={user.id}>
											{user.first_name}&nbsp;({user.username })
										</option>
									))}
								</select>
							</div>
						</div>

					</div>
				</div>
			</div>
			<div className="row">

				<div className="form-group col-md-6">
					<label className="form-label">Name</label>
					<input disabled type="text" value={first_name} onChange={e => setFirst_name(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label"  >Last Name</label>
					<input disabled type="text" required
						value={last_name} onChange={e => setLast_name(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" type="text" >User ID</label>
					<input disabled type="text" value={username} onChange={e => setUsername(e.target.value)} className="form-control" id="" />
				</div>
				{/* <div className="form-group col-md-6" as={Col} controlId="my_multiselect_field">
					<label className="form-label" >Line of Business</label>
					<select disabled className="form-control" style={{height:'60px'}} as="select" multiple value={lob} onChange={e => setLob([].slice.call(e.target.selectedOptions).map(item => item.value))}>
						<option value="expense">Expense</option>
						<option value="indemnity">Indemnity</option>
						<option value="rcs">RCS</option>
					</select>
				</div> */}
				<div className="form-group col-md-6" as={Col} controlId="my_multicheckbox">
				<label className="form-label" >Line of Business</label>
					<fieldset className='padding-top'>
					<input type="checkbox" disabled id="expensechkbox" name="expense" value="expense" />&nbsp;&nbsp;Expense &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="checkbox" disabled id="indemnitychkbox"   name="indemnity" value="indemnity" />&nbsp;&nbsp;Indemnity &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="checkbox" disabled id="rcschkbox" name="rcs" value="rcs" />&nbsp;&nbsp;RCS
					</fieldset>
				</div>
				<div className=" form-group col-md-6">
					<label className="form-label" type="text" >Role</label>
					<Form.Select disabled aria-label="" value={role} onChange={e => setRole(e.target.value)} className="form-control color">
						<option>select</option>
						<option value="1">Admin</option>
						<option value="2">Manager</option>
						<option value="3">Operator</option>
					</Form.Select>
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" type="text" >Contact number</label>
					<input disabled type="text" className="form-control" maxlength="10" value={contact_number} onChange={e => setContact_number(e.target.value)} id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" type="email" >Email address</label>
					<input type="email" className="form-control" value={email} onChange={e => setEmail(e.target.value)} id="" disabled />
				</div>


				<div className=" form-group col-md-12">
					<input className="form-group  btn btn-warning  sub-button" type="button" value={loading ? "Loading..." : "Deactivate User"} onClick={handleDeactivate} />
					{/* <a href=""  className="form-group  btn btn-warning  sub-button">Update User</a> */}
				</div>
			</div>
			<ToastContainer
				position="top-right"
				autoClose={5000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
				theme='colored'
			/>
		</div>

	)
}

export default Deactivate;