import React, { useState, useEffect } from 'react';
import { showToaster, getUserSession} from "../Utils/common";
import {Col, Form} from 'react-bootstrap';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';
import { addUserValidations } from './adminValidations';


const Adduser = (props) => {

	const session = getUserSession()
	if (session == null) {
		props.history.push('/');
	}
	// console.log("Session : " + session)
	const [email, setEmail] = useState('');
	const [first_name, setFirst_name] = useState('');
	const [username, setUsername] = useState('');
	const [last_name, setLast_name] = useState('');
	const [userid, setUserid] = useState('');
	const [password, setPassword] = useState('');
	const [role, setRole] = useState('');
	const [contact_number, setContact_number] = useState('');
	const [Post, setPost] = useState([]);
	const [error, setError] = useState(null);	
	const [loading, setLoading] = useState(false);
	const [lob, setLob] = useState([]);
	const [is_admin, setIsAdmin] = useState(0);
	const [is_manager, setIsmanager] = useState(0);
	const [successMessage, setSuccessMessage] = React.useState("");
	var is_mgr = false;
	var is_admin2 = false;
		
	const handleAdduser = async () => {
		let lob_list = [];
		if(document.getElementById("rcschkbox").checked) {
			lob_list.push(document.getElementById("rcschkbox").value)
		}
		if(document.getElementById("expensechkbox").checked) {
			lob_list.push(document.getElementById("expensechkbox").value)
		}
		if(document.getElementById("indemnitychkbox").checked) {
			lob_list.push(document.getElementById("indemnitychkbox").value)
		}
		let validated = addUserValidations(email, first_name, last_name, username, role, password, lob_list, contact_number, "addUser")
		if (validated.error) {
			showToaster(validated.message, "info");
			return
		}
		
		
		if (role == '1') {
			
			setIsAdmin(1);
			setIsmanager(0);
			is_mgr = false;
			is_admin2 = true;

		} else if (role == '2') {
			setIsAdmin(0);
			setIsmanager(1);
			is_mgr = true;
			is_admin2 = false;
		} else if (role  == "3"){
			setIsAdmin(0);
			setIsmanager(0);
			is_mgr = false;
			is_admin2 = false;
		}
		// console.log(getUserSession());
		
		
		const response = await fetch(process.env.REACT_APP_API_URL+"/api/users/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			
			body: JSON.stringify({
				
				"data": {
					user: {
						email: email,
						first_name: first_name,
						username: username,
						last_name: last_name,
						is_manager: is_mgr,
						is_admin: is_admin2,
						password: password,
						contact_number:contact_number
					},
					"proccess_type": lob_list

				}
			})
		}).then(response => response.json())
			.then(data => {
				//setIsAdmin(0);
			   //setIsmanager(0);
				// console.log("response")
				// console.log(data)
				setLoading(false);				
				if (data.error == true) {
					showToaster(data.message, 'error')
				}
				else {
				// setSuccessMessage(data.message)
				showToaster(data.message, 'success');
				setEmail("");
						setFirst_name("");
						setUsername("");
						setLast_name("");
						setRole("");
						setLob("");
						setPassword("");
						setContact_number("");
						document.getElementById("expensechkbox").checked = 0;
					document.getElementById("rcschkbox").checked = 0;
					document.getElementById("indemnitychkbox").checked = 0;
					
			}


			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				setLoading(false);
				showToaster('Something went wrong', 'error')
			});
	}
	return (
		<div className="col-md-12  user-details">

			<h2>Add User</h2>
			<div className="row">
				{successMessage && <div className="success"> {successMessage} </div>}
				<div className="form-group col-md-6">
					<label className="form-label"  >First Name</label>
					<input type="text" required
        value={first_name}  onChange={e => setFirst_name(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
				<label className="form-label"  >Last Name</label>
					<input type="text" required
        value={last_name}  onChange={e => setLast_name(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label">User ID</label>
					<input type="text" required value={username} onChange={e => setUsername(e.target.value)} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6" as={Col} controlId="my_multicheckbox">
				<label className="form-label" >Line of Business</label>
					<fieldset className='padding-top'>
					<input type="checkbox" id="expensechkbox" name="expense" value="expense" />&nbsp;&nbsp;Expense &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="checkbox" id="indemnitychkbox"   name="indemnity" value="indeminity" />&nbsp;&nbsp;Indeminity &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
					<input type="checkbox" id="rcschkbox" name="rcs" value="rcs" />&nbsp;&nbsp;RCS
					</fieldset>
				</div>
				{/* <div className="form-group col-md-6" as={Col} controlId="my_multiselect_field">
					<label className="form-label" >Line of Business</label>
					<select className="form-control" style={{height:'60px'}} as="select" multiple value={lob} onChange={e => setLob([].slice.call(e.target.selectedOptions).map(item => item.value))}>
						<option value="expense">Expense</option>
						<option value="indemnity">Indemnity</option>
						<option value="rcs">RCS</option>
					</select>	
				</div> */}
				<div className=" form-group col-md-6">
					<label className="form-label" >Role</label>
					<Form.Select aria-label="" required value={role}  onChange={e => setRole(e.target.value)} className="form-control color">
						<option>select</option>
						<option value="1">Admin</option>
						<option value="2">Manager</option>
						<option value="3">Operator</option>
					</Form.Select>
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" >Contact number</label>
					<input type="text" value={contact_number}  maxlength="10" onChange={(e) => {
						setContact_number(e.target.value);
						if (e.target.value.length > 10) {
							setError(true);
						}
					}} className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" >Email address</label>
					<input type="email" value={email}  required onChange={e => setEmail(e.target.value)}  className="form-control" id="" />
				</div>
				<div className="form-group col-md-6">
					<label className="form-label" >Password </label>
					<input type="password" value={password} required onChange={e => setPassword(e.target.value)} className="form-control" id="" />
				</div>
				<div className=" form-group col-md-12">
					<p>{Post.value}</p>
					<input className="form-group  btn btn-warning  sub-button" type="button" value={loading ? "Loading..." : "Add User"}  onClick={handleAdduser} />
				</div>
			</div>
			<ToastContainer
		position="top-right"
		autoClose={5000}
		hideProgressBar={false}
		newestOnTop={false}
		closeOnClick
		rtl={false}
		pauseOnFocusLoss
		draggable
		pauseOnHover
		theme='colored'
/>
		</div>



	)
}
export default Adduser;