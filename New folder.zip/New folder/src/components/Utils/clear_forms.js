import $ from 'jquery/src/jquery';


const clearFormsFunction = (form_count) => {
    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.
    var jQueryScript = document.createElement('script');
    jQueryScript.setAttribute('src', 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
    document.head.appendChild(jQueryScript);

    $(document).ready(function () {
        //var form_count = -1;
        
        
        for (var count = 0; count <= form_count; count++) {
           var pay_stamp = document.getElementById("pay_stamp" + count);
           if (pay_stamp){
            pay_stamp.value = "";
           }
            
            var paykind_code1 =  document.getElementById("paykind_code1" + count);
                if (paykind_code1){
                    paykind_code1.value = "";
                   }

            var paykind_code2  = document.getElementById("paykind_code2" + count);
            if (paykind_code2){
                paykind_code2.value = "";
               }
            var paykind_code3 = document.getElementById("paykind_code3" + count);
            if (paykind_code3){
                paykind_code3.value = "";
               }
            var valid1 = document.getElementById("valid1" + count);
            if (valid1){
                valid1.value = "";
               }
            var valid2 = document.getElementById("valid2" + count);
            if (valid2){
                valid2.value = "";
               }
            var sub = document.getElementById("sub" + count);
            if (sub){
                sub.value = "";
               }
            var servicestate = document.getElementById("servicestate" + count);
            if (servicestate){
                servicestate.value = "";
               }
            var claimnumber = document.getElementById("claimnumber" + count);
            if (claimnumber){
                claimnumber.value = "";
               }
            var invoiceno = document.getElementById("invoiceno" + count);
            if (invoiceno){
                invoiceno.value = "";
               }
            var firstname = document.getElementById("firstname" + count);
            if (firstname){
                firstname.value = "";
               }
            var lastname = document.getElementById("lastname" + count);
            if (lastname){
                lastname.value = "";
               }
            var specialinstructions1 = document.getElementById("specialinstructions1" + count);
            if (specialinstructions1){
                specialinstructions1.value = "";
               }
            var specialinstructions2 = document.getElementById("specialinstructions2" + count);
            if (specialinstructions2){
                specialinstructions2.value = "";
               }
            var closeclaim = document.getElementById("closeclaim" + count);
            if (closeclaim){
                closeclaim.value = "No";
               }
            var payableamount1 = document.getElementById("payableamount1" + count);
            if (payableamount1){
                payableamount1.value = "";
               }
            var payableamount2 = document.getElementById("payableamount2" + count);
            if (payableamount2){
                payableamount2.value = "";
               }
            var dateofservice1 = document.getElementById("dateofservice1" + count);
            if (dateofservice1){
                dateofservice1.value = "";
               }
            var dateofservice2 = document.getElementById("dateofservice2" + count);
            if (dateofservice2){
                dateofservice2.value = "";
               }
            var taxid = document.getElementById("taxid" + count);
            if (taxid){
                taxid.value = "";
               }
            var payeename = document.getElementById("payeename" + count);
            if (payeename){
                payeename.value = "";
               }
            var mailtoname = document.getElementById("mailtoname" + count);
            if (mailtoname){
                mailtoname.value = "";
               }
            var address1=  document.getElementById("address1" + count);
            if (address1){
                address1.value = "";
               }
            var address2 = document.getElementById("address2" + count);
            if (address2){
                address2.value = "";
               }
            var cityname = document.getElementById("cityname" + count);
            if (cityname){
                cityname.value = "";
               }
            var zipcode = document.getElementById("zipcode" + count);
            if (zipcode){
                zipcode.value = "";
               }
            var state = document.getElementById("state" + count);
            if (state){
                state.value = "";
               }
            var PageNo = document.getElementById("PageNo" + count);
            if (PageNo){
                PageNo.value = "";
               }
            var natureofpayment = document.getElementById("natureofpayment" + count);
            if (natureofpayment){
                natureofpayment.value = "/n";
               }
            var taxable = document.getElementById("taxable" + count);
            if (taxable){
                taxable.value = "No";
               }
            var taxableto = document.getElementById("taxableto" + count);
            if (taxableto){
                taxableto.value = "V- Vendor" ;
               }
            var mcsc = document.getElementById("mcsc" + count);
            if (mcsc){
                mcsc.value = "No";
               }
            var settlement_code1 = document.getElementById("settlement_code1" + count);
            if (settlement_code1){
                settlement_code1.value = "";
               }
            var settlement_code2  = document.getElementById("settlement_code2" + count);
            if (settlement_code2){
                settlement_code2.value = "";
               }
      
        }
        // if (form_count > 0 ) {
        //     document.getElementById("delete_" + count).click();
        // }
        document.getElementById("pay_stamp0").focus();
        

    });
}


export default clearFormsFunction;
