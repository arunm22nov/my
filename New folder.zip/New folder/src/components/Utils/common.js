import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.min.css';

export const getUser =() => {
const userStr = localStorage.getItem("user");
if (userStr) return JSON.parse(userStr).f_name;
else return null;

}

export const getToken=() => {
return localStorage.getItem ("token") || null;
}

export const setUserSession = (token, user) =>{
 localStorage.setItem("token", token);
localStorage.setItem ("user", JSON.stringify(user));
}
export const removedUserSession = () => {
    
localStorage.removeItem("token");
localStorage.removeItem("user");

}
export const getUserSession = () =>{
    // console.log(JSON.parse(localStorage.getItem("token")));
    // console.log(localStorage.getItem("token"));
    if (JSON.parse(localStorage.getItem("token")) != null) {
        return  JSON.parse(localStorage.getItem("token")).access;
    } else {
        return null;
    }


}
export const showToaster = ((message, notificationType) => {
    if (notificationType == 'error'){
        toast.error(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
    }
    else if(notificationType == 'success'){
        toast.success(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
    } else if(notificationType == "info") {
        toast.warn(message, {
            position: "top-right",
            autoClose: 5000,
            hideProgressBar: false,
            closeOnClick: true,
            pauseOnHover: true,
            draggable: true,
            progress: undefined,
            });
    }

});

