import $ from 'jquery/src/jquery';


const deleteForm = (extracted_json) => {
    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.
    var jQueryScript = document.createElement('script');
    jQueryScript.setAttribute('src', 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
    document.head.appendChild(jQueryScript);

    $(document).ready(function () {
        var appndList = document.querySelectorAll("#formId .form");

           

        for (var i=0; i < appndList.length; i++){

            appndList[i].remove();

            // console.log("append item removed---------------->" +appndList[i]);

           

        }

     

         var acc = document.getElementsByClassName("accordion");

         var panel = acc[0].nextElementSibling;

         panel.style.display = "block";
    });
}


export default deleteForm;
