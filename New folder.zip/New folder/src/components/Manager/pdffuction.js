import $ from 'jquery/src/jquery';
import { ToastContainer, toast } from 'react-toastify';
import { getUser, removedUserSession, getUserSession, showToaster } from "../Utils/common";
import * as pdfjsLib from "pdfjs-dist/webpack";
import pdfjsWorker from "pdfjs-dist/build/pdf.worker.entry";
import "pdfjs-dist/web/pdf_viewer.css";


const pdfFunction = (converted_doc, original_doc) => {
    // If absolute URL from the remote server is provided, configure the CORS
    // header on that server.
    var jQueryScript = document.createElement('script');
    jQueryScript.setAttribute('src', 'https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js');
    document.head.appendChild(jQueryScript);



    $(document).ready(function () {
        var original_doc_url = original_doc
        var converted_doc_url = converted_doc

        $("#pdfcontainer").hide();
        var url = converted_doc
        // "{% static 'test1.pdf' %}";

        // Loaded via <script> tag, create shortcut to access PDF.js exports.
        
        //window['pdfjs-dist/build/pdf'];

        // The workerSrc property shall be specified.
        // pdfjsLib.GlobalWorkerOptions.workerSrc = '//mozilla.github.io/pdf.js/build/pdf.worker.js';

        var pdfDoc = null,
            pageRendering = false,
            pageNumPending = null,
            //scale = 0.8,
            scale = 0;

        var lastFocus = "";

        var currentFocus = "";
        // pdfjsLib = window['pdfjs-dist/build/pdf'];
        // pdfjsLib.GlobalWorkerOptions.workerSrc = 'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.0.279/pdf.worker.js';
        pdfjsLib.GlobalWorkerOptions.workerSrc = pdfjsWorker;
        let canvas = document.getElementById('the-canvas');
        let ctx = canvas.getContext('2d');
        let pageNum = 1;




    

        function changeSpanWidth() {
            var spans = document.getElementById('textLayer').getElementsByTagName('span');
            for (var i = 0; i < spans.length; i++) {
                var transformStyle = (spans[i].style.transform);
                var scaleX = parseFloat(transformStyle.replace(/[^\d.]/g, ''));
                var newScale = scaleX + 0.162;
                var spanLeft = parseFloat(spans[i].style.left);
                var newSpanLeft = spanLeft - 0.93;
                spans[i].style.left = newSpanLeft + "px";
                spans[i].style.transform = 'scaleX(' + newScale + ')';
            }
        }

        function getdoc(url,manual_scale) {
            if (url && url != "None") {
                //bject.prototype.toString.call(url)
                $("#pdfcontainer").show();

                //alert(url);

            } else {
                $("#pdfcontainer").hide();
                return;
            }


            pageRendering = false;
            pageNumPending = null;
            if (manual_scale == null) {
                scale = 1.2;
            }
            else {
                scale = manual_scale;
            }
            



            //url = "{% static 'test1.pdf' %}";
            pdfjsLib.getDocument(url, null).promise.then(function (pdfDoc_) {
                pdfDoc = pdfDoc_;
                document.getElementById('page_count').textContent = pdfDoc.numPages;

                // Initial/first page rendering
                renderPage(pageNum);
            })
                .catch(function () {

                    document.getElementById("textLayer").style.display = "none";

                    document.getElementById("errorPdf").style.display = "block";

                    document.getElementById("pdfcontainer").style.display = "none";

                });

        }



        

        /**
         * Get page info from document, resize canvas accordingly, and render page.
         * @param num Page number.
         */
        function renderPage(num) {
            pageRendering = true;
            // Using promise to fetch the page
            pdfDoc.getPage(num).then(function (page) {
                var viewport = page.getViewport({ scale: scale });
                canvas.height = viewport.height;
                canvas.width = viewport.width;

                // Render PDF page into canvas context
                var renderContext = {
                    canvasContext: ctx,
                    viewport: viewport
                };
                var renderTask = page.render(renderContext);

                // Wait for rendering to finish
                renderTask.promise.then(function () {
                    pageRendering = false;
                    if (pageNumPending !== null) {
                        // New page rendering is pending
                        renderPage(pageNumPending);
                        pageNumPending = null;
                    }
                }).then(function () {
                    // Returns a promise, on resolving it will return text contents of the page
                    return page.getTextContent();
                }).then(function (textContent) {
                    $('#textLayer').find('span').remove()

                    var textLayer = document.querySelector(".textLayer");

                    textLayer.style.left = canvas.offsetLeft + 'px';
                    textLayer.style.top = canvas.offsetTop + 'px';
                    textLayer.style.height = canvas.offsetHeight + 'px';
                    textLayer.style.width = canvas.offsetWidth + 'px';

                    //	Pass the data to the method for rendering of text over the pdf canvas.
                    pdfjsLib.renderTextLayer({
                        textContent: textContent,
                        container: textLayer,
                        viewport: viewport,
                        textDivs: []
                    });

                }).then(function () {
                    changeSpanWidth()
                });
            });

            // Update page counters
            document.getElementById('page_num').textContent = num;
        }

        /**
         * If another page rendering in progress, waits until the rendering is
         * finised. Otherwise, executes rendering immediately.
         */
        function queueRenderPage(num) {
            if (pageRendering) {
                pageNumPending = num;
            } else {
                renderPage(num);
            }
        }

        /**
         * Displays previous page.
         */
        function onPrevPage() {
            if (pageNum <= 1) {
                return;
            }
            pageNum--;
            queueRenderPage(pageNum);
        }
        document.getElementById('prev').addEventListener('click', onPrevPage);

        /**
         * Displays next page.
         */
        function onNextPage() {
            if (pageNum >= pdfDoc.numPages) {
                return;
            }
            pageNum++;
            queueRenderPage(pageNum);
        }
        document.getElementById('next').addEventListener('click', onNextPage);

        /**
        * Zoom In.
        */
        function zoomIn() {
            scale = scale + 0.5;
            renderPage(pageNum, scale)
        }
        document.getElementById('zoomIn').addEventListener('click', zoomIn);

        /**
         * Zoom out.
         */
        function zoomOut() {
            if (scale-0.5 <0) {
                return
            }
            scale = scale - 0.5;
            renderPage(pageNum, scale)
        }
        document.getElementById('zoomOut').addEventListener('click', zoomOut);
 
       
        document.onmouseup = document.onkeyup = document.onselectionchange = function () {

            let text = window.getSelection().toString().trim();

            text = text.replace(/([.,\/#!$%\^&\*;:{}=\-_`~()\]\[])+$/g, "");
            $('body').on('keydown', 'input', function(e){

                var keyCode = e.keyCode || e.which;

                if (keyCode == 9 && this.tagName === "INPUT") {

                 lastFocus="";

                 text="";

                }

              });

            var current_focus = "";

              $(":focus").each(function () {

                //alert("Focused Elem_id = "+ this.id );

                current_focus = this.id;

              });

            // console.log("current focus :" + current_focus);

            // console.log("last focus :" + lastFocus);

                     

            if ((lastFocus.startsWith("state")) || (lastFocus.startsWith("taxable")) 
            || (lastFocus.startsWith("mcsc")) || (lastFocus.startsWith("servicestate")) 
            || (lastFocus.startsWith("closeclaim")))
            {
                return
            }

            if (text && lastFocus && current_focus != lastFocus)
           // if (text && lastFocus) 
            {

                // $("#" + lastFocus).val(text);
                //alert (lastFocus + count);
                var hold_lastfocus = lastFocus;
                var payableamount = "payableamount" ;
                //var payableamount1 = "payableamount1" ;
                var PageNo = "PageNo";
                var sub = "sub";
                var servicestate = "servicestate";
                var claimnumber = "claimnumber";
                var taxid = "taxid";
                var state = "state"  ;
                var dateofservice = "dateofservice"  ;
                var withoutdigit_lastfocusid = lastFocus;
                //hold_lastfocus.replace(/[0-9]/g, "");
                var isValid = true;
                //FOR TEXT LIMIT
               
                if (withoutdigit_lastfocusid.includes("pay_stamp")){
                    text = text.substring(0, 20);
                }
                if (withoutdigit_lastfocusid.includes("paykind_code1")){
                    text = text.substring(0, 10);
                }
                if (withoutdigit_lastfocusid.includes("paykind_code2")){
                    text = text.substring(0, 10);
                }
                if (withoutdigit_lastfocusid.includes("paykind_code3")){
                    text = text.substring(0, 10);
                }
                if (withoutdigit_lastfocusid.includes("valid")){
                    text = text.substring(0, 20);
                }
                if (withoutdigit_lastfocusid.includes("invoiceno")){
                    text = text.substring(0, 50);
                }
                if (withoutdigit_lastfocusid.includes("firstname")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("lastname")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("specialinstructions1")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("specialinstructions2")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("payeename")){
                    text = text.substring(0, 200);
                }
                if (withoutdigit_lastfocusid.includes("mailtoname")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("address1")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("address2")){
                    text = text.substring(0, 100);
                }
                if (withoutdigit_lastfocusid.includes("zipcode")){
                    text = text.substring(0, 10);
                }
                if (withoutdigit_lastfocusid.includes("cityname")){
                    text = text.substring(0, 50);
                }
                if (withoutdigit_lastfocusid.includes("PageNo")){
                    text = text.substring(0, 2);
                }
                if (withoutdigit_lastfocusid.includes("natureofpayment")){
                    text = text.substring(0, 50);
                }

                if (withoutdigit_lastfocusid.includes(payableamount)) {
                    isValid = false;
                    // $("#" + lastFocus).on("input", function() {
                    //     // console.log($(this).val());
                    //     var payable_txt =  $(this).val() ;
                    //     if (payable_txt.length < 1000000) {
            
                    //         $("#" + lastFocus).val(text);
                    //         $("#alert_payable" + (lastFocus.match(/\d/g)).join("")).hide();
                            
                    //     }
                    //     else{
                    //         $("#alert_payable" + (lastFocus.match(/\d/g)).join("")).show();
                    //     }
                    //  });
                    // console.log((lastFocus.match(/\d/g)).join(""))

                    var selected_val = parseFloat(text);
                    if (selected_val < 1000000) {
                        $("#" + lastFocus).val(text);
                        $("#alert_payable" + (lastFocus.match(/\d/g)).join("")).hide();
                    } else {
                        //showToaster('Enter Payable amount less than 1 million', 'info');
                        $("#" + lastFocus).val(text.substring(0,9));
                        $("#alert_payable" + (lastFocus.match(/\d/g)).join("")).show();
                    }
                }
                // if (withoutdigit_lastfocusid.includes(payableamount1)) {
                //     isValid = false;

                //     var selected_val = parseFloat(text);
                //     if (selected_val < 500) {
                //         $("#" + lastFocus).val(text);
                //         $("#alert_payable2" + (lastFocus.match(/\d/g))).hide();
                //     } else {
                //         //showToaster('Enter Payable amount less than 1 million', 'info');
                        
                //         $("#alert_payable2" + (lastFocus.match(/\d/g))).show();
                //     }
                // }
            //     //sub = "sub" +  (count - 1);
            //    // alert(sub + " "+ "alert_sub" + (count - 1));



                if (withoutdigit_lastfocusid.includes(sub)) {
                    
                    isValid = false;
                    $("#" + lastFocus).on("input", function() {
                        // console.log($(this).val());
                        var sub_txt =  $(this).val() ;
                        if (sub_txt.length == 3) {
            
                            $("#alert_sub" + (lastFocus.match(/\d/g))).hide();
                            
                        }
                        else{
                            $("#alert_sub" + (lastFocus.match(/\d/g))).show();
                        }
                     });
                    if (text.length == 3) {
                        $("#" + lastFocus).val(text);
                        // $("#alert_sub").hide();
                        $("#alert_sub" + (lastFocus.match(/\d/g))).hide();
                    } else {
                        //showToaster('Enter Payable amount less than 1 million', 'info');
                        
                        // $("#alert_sub").show();
                        $("#" + lastFocus).val(text.substring(0,3));
                        $("#alert_sub" + (lastFocus.match(/\d/g))).show();

                    }
                }
                if (withoutdigit_lastfocusid.includes(servicestate)) {
                    if (text.length == 2) {
                        $("#" + lastFocus).val(text);
                        // $("#alert_servicestate").hide();
                        $("#alert_servicestate" + (lastFocus.match(/\d/g))).hide();
                    } else {
                        //showToaster('Enter Payable amount less than 1 million', 'info');
                        isValid = false;
                        // $("#alert_servicestate").show();
                        $("#alert_servicestate" + (lastFocus.match(/\d/g))).show();
                    }
                }

                if (withoutdigit_lastfocusid.includes(claimnumber)) {
                    isValid = false;
                    $("#" + lastFocus).on("input", function() {
                        // console.log($(this).val());
                        var claimnumber_txt =  $(this).val() ;
                        if (claimnumber_txt.length == 10) {
            
                            $("#alert_claimnumber" + (lastFocus.match(/\d/g))).hide();
                            
                        }
                        else{
                            $("#alert_claimnumber" + (lastFocus.match(/\d/g))).show();
                        }
                     });
                    if (text.length == 10) {                       
                        $("#" + lastFocus).val(text);
                        // $("#alert_claimnumber").hide();
                        $("#alert_claimnumber" + (lastFocus.match(/\d/g))).hide();
                    } else {
                        //showToaster('Enter Payable amount less than 1 million', 'info');
                        
                        // $("#alert_claimnumber").show();
                        $("#" + lastFocus).val(text.substring(10,10));
                        $("#alert_claimnumber" + (lastFocus.match(/\d/g))).show();
                    }
                }
                if (withoutdigit_lastfocusid.includes(taxid)) {
                    var tax_withouthyp = text.replace('-',"");
                    isValid = false;
                    $("#" + lastFocus).on("input", function() {
                        // console.log($(this).val());
                        var taxid_txt =  $(this).val() ;
                        if (taxid_txt.length == 9) {
            
                            $("#alert_taxid" + (lastFocus.match(/\d/g))).hide();
                            
                        }
                        else{
                            $("#alert_taxid" + (lastFocus.match(/\d/g))).show();
                        }
                     });
                    if (tax_withouthyp.length == 9) {
                        $("#" + lastFocus).val(tax_withouthyp);
                        //  $("#alert_taxid").hide();
                         $("#alert_taxid" + (lastFocus.match(/\d/g))).hide();
                    } else {
                        //showToaster('Enter Payable amount less than 1 million', 'info');
                        // isValid = false;
                        //  $("#alert_taxid").show();
                        $("#" + lastFocus).val(text.substring(0,9));
                         $("#alert_taxid" + (lastFocus.match(/\d/g))).show();
                    }
                }
                if (withoutdigit_lastfocusid.includes(dateofservice)) {
                    
                    isValid = false;
                    
                    if (text.includes("/")) {
                        var splt_text = text.split("/")
                        var date = splt_text[0] +"/"+ splt_text[1] + "/" + splt_text[2].slice(-2);
                        $("#" + lastFocus).val(date);
                        
                    } else {
                        $("#" + lastFocus).val(text);
                         
                    }
                }
                if (withoutdigit_lastfocusid == state) {
                    isValid = false;


                    if (text.length == 2) {
                        $("#" + lastFocus).val(text);
                        $("#alert_state").hide();
                    } else {
                        //showToaster('Enter Payable amount less than 1 million', 'info');
                        $("#alert_state").show();
                    }
                }



                if (isValid) {
                    $("#" + lastFocus).val(text);
                }
            }




        };


        function delete_forms_test() {
            console.log("delete btn pressed")
            var appndList = document.querySelectorAll("#formId .form");

            for (var i=0; i < appndList.length; i++){
    
                appndList[i].remove();
    
            }
    
            //  var acc = document.getElementsByClassName("accordion");
    
            //  var panel = acc[0].nextElementSibling;
    
            //  panel.style.display = "block";
             count = 1

             var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function () {
                /* Toggle between adding and removing the "active" class,
                to highlight the button that controls the panel */
                this.classList.toggle("active");

                /* Toggle between hiding and showing the active panel */
                var panel = this.nextElementSibling;
                if (panel.style.display === "block") {
                    panel.style.display = "none";
                } else {
                    panel.style.display = "block";
                }
            });
        }
        
        }
        document.getElementById('delete_btn').addEventListener('click', delete_forms_test);



        function onAccordionClick(button) {
            // console.log(global_count)
            var acc = document.getElementsByClassName("accordion");
            var i;
            // console.log("accordion check")

            for (i = 0; i < acc.length; i++) {
                var panel = acc[i].nextElementSibling;
                panel.style.display = "none";
                if (i < count - 1) {
                    continue
                }
                var panel = acc[i].nextElementSibling;
                panel.style.display = "block";
                var elemEventHandler = function () { };
                acc[i].addEventListener("click", elemEventHandler, false);
                // $(acc[i]).removeAttr('onclick');
                acc[i].addEventListener("click", function () {
                    /* Toggle between adding and removing the "active" class,
                    to highlight the button that controls the panel */
                    this.classList.toggle("active");

                    /* Toggle between hiding and showing the active panel */
                    var panel = this.nextElementSibling;
                    if (panel.style.display === "block") {
                        panel.style.display = "none";
                    } else {
                        panel.style.display = "block";
                    }
                });
            }
        }



        var count = 1;
        var global_count = 1;
        var getFormId = "";

        // getdoc("http://localhost:8000/_1340149920.pdf")


        $("#addform").on("click", function () {
            // console.log("add form")
            var cols = "";
            var l1 = $("<div class='form'>");
            var counter = 1;
            var localCount = 1;


            cols += '<input type="text" class="form-control" id="name' + count + '"/>';



            let html1 = $("<div>")
                //.append($("<div class='row justify-content-between m-0 p-0'>")
                //.append($("<div class='col-6'>")
                .append($('<button type="button" class="btn btn-warning remove-form" id="delete_' + count + '">-</button>'))
                .append($("<button class='accordion' id='accordionBtn" + count + "'>New Form</button>"))

                //.append($("<div class='col-6 d-flex flex-row justify-content-end'>")
                ;
            //$("#content").empty();

            //currentFocus = "22222"
            //"input" + count + (localCount + 1) ;



            let html = html1.append(
                $("<div  class='panel m-1 p-1'>").append($("<div class='row m-0 p-0'>")
                    .append($("<div class='row m-0 p-0' > ")
                        .append($("<div class='col-md-6' > ")
                            .append('<label >OK to Pay Stamp</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" id="pay_stamp' + count + '" > '))
                        
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Paykind code 1</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="paykind_code1' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Paykind code 2</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="paykind_code2' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Paykind code 3</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="paykind_code3' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Sub#</label>')                            
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="sub' + count + '">')
                            .append('<div  class="message display"  id="alert_sub' + count + '">Sub value should be in 3 digits. By default value is 001</div>'))
                        .append($("<div class='col-md-6' > ")
                           .append('<label class="" >Settlement Code-Paykind Code 1</label>')
                            .append('<input autofocus type="text" class="  border border-1 m-0 form-control" placeholder="" id="settlement_code1' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Settlement Code-Paykind Code 2</label>')
                            .append('<input autofocus type="text" class="  border border-1 m-0 form-control" placeholder="" id="settlement_code2' + count + '">'))
                       
                         
                        .append($("<div class='col-md-6' > ")
                            .append('<label class="" >Val ID 1</label>')
                            .append('<input autofocus type="text" class="  border border-1 m-0 form-control" placeholder="" id="valid1' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label class="" >Val ID 2</label>')
                            .append('<input autofocus type="text" class="  border border-1 m-0 form-control" placeholder="" id="valid2' + count + '">'))
                        
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Service State</label>')
                            .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="servicestate' + count + '"><option value="AL" selected>AL</option><option>AK</option><option>AZ</option><option >AR</option><option>CA</option><option value="CO">CO</option><option value="CT">CT</option><option value="DE">DE</option><option value="DC">DC</option><option value="FL">FL</option><option value="GA">GA</option><option value="HI">HI</option><option value="ID">ID</option><option value="IL">IL</option><option value="IN">IN</option><option value="IA">IA</option><option value="KS">KS</option><option value="KY">KY</option><option value="LA">LA</option><option value="ME">ME</option><option value="MD">MD</option><option value="MA">MA</option><option value="MI">MI</option><option value="MN">MN</option><option value="MS">MS</option><option value="MO">MO</option><option value="MT">MT</option><option value="NE">NE</option><option value="NV">NV</option><option value="NH">NH</option><option value="NJ">NJ</option><option value="NM">NM</option><option value="NY">NY</option><option value="NC">NC</option><option value="ND">ND</option><option value="OH">OH</option><option value="OK">OK</option><option value="OR">OR</option><option value="PA">PA</option><option value="RI">RI</option><option value="SC">SC</option><option value="SD">SD</option><option value="TN">TN</option><option value="TX">TX</option><option value="UT">UT</option><option value="VT">VT</option><option value="VA">VA</option><option value="WA">WA</option><option value="WV">WV</option><option value="WI">WI</option><option value="WY">WY</option> </select>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Claim Number</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="claimnumber' + count + '">')
                            .append('<div  class="message display"  id="alert_claimnumber' + count + '">Claim number should be in 10 digits</div>'))

                        .append($("<div class='col-md-6' > ")
                            .append('<label >Requestor First name</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="firstname' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Requestor Last name</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="lastname' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Invoice No</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="invoiceno' + count + '">'))
                            .append($("<div class='col-md-6' > ")
                            .append('<label >Close claim</label>')
                            .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="closeclaim' + count + '"> <option>Yes</option><option>No</option> </select>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Special instructions 1</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="specialinstructions1' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Special instructions 2</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="specialinstructions2' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Total payable amount_paykind code 1*</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="payableamount1' + count + '">')
                            .append('<div  class="message display"  id="alert_payable1' + count + '">Payable amount can not be more than 1 million</div>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Total payable amount_paykind code 2 </label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="payableamount2' + count + '">')
                            .append('<div  class="message display"  id="alert_payable2' + count + '">Payable amount can not be more than 1 million</div>'))
                        // .append($ ("<div class='col-md-12'> ")
                        // .append('<div  class="message display"  id="alert_payable' + count + '">Payable amount can not be more than 1 million</div>'))
                            .append($("<div class='col-md-6' > ")
                            .append('<label >Date of service*</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="dateofservice1' + count + '">')
                            .append('<div  class="message display" id="alert_dateofservice1' + count + '"  >Enter Date of service mm/dd/yy format</div>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >&nbsp;</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="dateofservice2' + count + '">')
                            .append('<div  class="message display" id="alert_dateofservice2' + count + '"  >Enter Date of service mm/dd/yy format</div>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Tax ID </label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="taxid' + count + '">')
                            .append('<div  class="message display"  id="alert_taxid' + count + '">Tax ID should be in 9 digits</div>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Payee Name*</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="payeename' + count + '">'))
                            .append($("<div class='col-md-6' > ")
                            .append('<label >Mail to Name*</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="mailtoname' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Address (Line 1)</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="address1' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Address (Line 2)</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="address2' + count + '">'))


                        .append($("<div class='col-md-6' > ")
                            .append('<label >City Name*</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="cityname' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Zip Code</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" placeholder="" id="zipcode' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >State</label>')
                            .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="state' + count + '"><option value="AL" selected>AL</option><option>AK</option><option>AZ</option><option >AR</option><option>CA</option><option value="CO">CO</option><option value="CT">CT</option><option value="DE">DE</option><option value="DC">DC</option><option value="FL">FL</option><option value="GA">GA</option><option value="HI">HI</option><option value="ID">ID</option><option value="IL">IL</option><option value="IN">IN</option><option value="IA">IA</option><option value="KS">KS</option><option value="KY">KY</option><option value="LA">LA</option><option value="ME">ME</option><option value="MD">MD</option><option value="MA">MA</option><option value="MI">MI</option><option value="MN">MN</option><option value="MS">MS</option><option value="MO">MO</option><option value="MT">MT</option><option value="NE">NE</option><option value="NV">NV</option><option value="NH">NH</option><option value="NJ">NJ</option><option value="NM">NM</option><option value="NY">NY</option><option value="NC">NC</option><option value="ND">ND</option><option value="OH">OH</option><option value="OK">OK</option><option value="OR">OR</option><option value="PA">PA</option><option value="RI">RI</option><option value="SC">SC</option><option value="SD">SD</option><option value="TN">TN</option><option value="TX">TX</option><option value="UT">UT</option><option value="VT">VT</option><option value="VA">VA</option><option value="WA">WA</option><option value="WV">WV</option><option value="WI">WI</option><option value="WY">WY</option> </select>'))
                         .append($("<div class='col-md-6' > ")
                            .append('<label >Page no. to apply Paid Stamp*</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" id="PageNo' + count + '" > '))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Nature of Payment</label>')
                            .append('<input type="text" class="border border-1 m-0 form-control" value="/n"  placeholder="" id="natureofpayment' + count + '">'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >1099</label>')
                            .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="taxable' + count + '"> <option>Yes</option><option>No</option> </select>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >Taxable to</label>')
                            .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="taxableto' + count + '"> <option value="">Select</option> <option>A- Attorney</option><option>B- Both (Attorney + Claimaint)</option><option>C- Claimaint</option><option selected>V- Vendor</option> </select>'))
                        .append($("<div class='col-md-6' > ")
                            .append('<label >MCSC</label>')
                            .append('<select class="form-select border border-1 m-0 form-control" placeholder="" id="mcsc' + count + '"> <option>yes</option><option selected>No</option> </select>'))
                    )));
            l1.append(html);
            $("#formId").append(l1);

            if (getFormId === "") {
                $(this).blur();


            }

            else {

                $("#" + getFormId).blur();





            }

            $("#pay_stamp" + count).focus();



            getFormId = "pay_stamp" + count;



            lastFocus = "pay_stamp" + count;



            count += 1;
            global_count += 1;
            onAccordionClick(count);

            //     var acc = document.getElementsByClassName("accordion");
            //     var i;
            //     // console.log("accordion check")

            //     for (i = 0; i < acc.length; i++) {
            //         this.classList.toggle("active");

            // /* Toggle between hiding and showing the active panel */
            // var panel = this.nextElementSibling;
            // if (panel.style.display === "block") {
            //   panel.style.display = "none";
            // } else {
            //   panel.style.display = "block";
            // }
            //     }
        });

        $('#formId').click(function () {

            $(":focus").each(function () {
                // console.log("delete form")
                //alert("Focused Elem_id = "+ this.id );
                lastFocus = this.id;


                var focus_id = this.id;
                var matches = focus_id.split("_");
                if (matches.length > 0) {
                    var deleteKey = matches[0]
                    if (deleteKey == "delete") {

                        $(this).closest(".form").remove();
                        count -= 1;
                        //$("#l1 li").eq(matches[1]-1).remove();
                        //alert(matches[1]);

                    }

                }


            });




        });

        $("#submitId").click(function () {
            alert(lastFocus);

        });


        $('#formId').click(function () {

            $(":focus").each(function() {
                var current_focus = this.id;
                var dateofservice = "dateofservice"  ;

                if (current_focus.includes(dateofservice)) {


                
                    $("#"+ current_focus).on("input" , function() {
                        
                        var date_regex = /^\d{2}\/\d{2}\/\d{2}$/;
                        var date_txt =  $(this).val() ;
                        if (!date_regex.test(date_txt)) {
            
                            $("#alert_dateofservice" + (current_focus.match(/\d/g)).join("")).show();
                            
                        }
                        else{
                            $("#alert_dateofservice" + (current_focus.match(/\d/g)).join("")).hide();
                        }
                     });

                    }
                
                  }); 



        });
        $('input').click(function(){ 
            $(":focus").each(function() {
                var current_focus = this.id;
                var dateofservice = "dateofservice"  ;

                if (current_focus.includes(dateofservice)) {


                
                    $("#"+ current_focus).on("input" , function() {
                        
                        var date_regex = /^\d{2}\/\d{2}\/\d{2}$/;
                        var date_txt =  $(this).val() ;
                        if (!date_regex.test(date_txt)) {
            
                            $("#alert_dateofservice" + (current_focus.match(/\d/g)).join("")).show();
                            
                        }
                        else{
                            $("#alert_dateofservice" + (current_focus.match(/\d/g)).join("")).hide();
                        }
                     });

                    }
                
                  }); });




        
       


        $("#b2").click(function () {
            if (count > 1) {
                $("#formId Div").last().remove();
                count -= 1;

            }


        });
        if ($('#btnradio2').is(':checked')) {
            url = converted_doc_url;

            //"{% static 'test1.pdf' %}";
            getdoc(url, null);
        }



        $($("#groupid")).change(function () {
            if ($('#btnradio2').is(':checked')) {
                url = converted_doc_url;
                //"{% static 'test1.pdf' %}";
                getdoc(url, null);
            }
            else if ($('#btnradio1').is(':checked')) {
                url = original_doc_url
                // alert(url);
                //"{% static 'test.pdf' %}";
                getdoc(url, null);

            }

        });


        
        var acc = document.getElementsByClassName("accordion");
        var i;

        for (i = 0; i < acc.length; i++) {
            acc[i].addEventListener("click", function () {
                /* Toggle between adding and removing the "active" class,
                to highlight the button that controls the panel */
                this.classList.toggle("active");

                /* Toggle between hiding and showing the active panel */
                var panel = this.nextElementSibling;
                if (panel.style.display === "block") {
                    panel.style.display = "none";
                } else {
                    panel.style.display = "block";
                }
            });
        }

    });

}
export default pdfFunction;