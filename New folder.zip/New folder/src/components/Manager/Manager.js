import React, { useEffect, useCallback } from 'react';
import { forwardRef, useState, useImperativeHandle, useRef } from "react";
import logo from '../../images/logo.png';
import logoexl from '../../images/exl-logo.png';
import Managervalidate from './Managervalidate';
import Managerlanding from './Managerlanding';
import { getUser, removedUserSession, getUserSession} from "../Utils/common";
import { BrowserRouter as Router, Route, Redirect } from 'react-router-dom';
import { Switch } from 'react-router-dom';

import 'react-toastify/dist/ReactToastify.min.css';
export default function Operator(props) {
	const session = getUserSession()
	if (session == null) {
		props.history.push('/');
	}
	// console.log("Session : " + session)
	const [open, setOpen] = useState(false);
	const user = getUser();
	const handleLogout = () => {
		removedUserSession();
		props.history.push('/');
	}

	return (

		<div className="background">
			<nav className=" bg-nav">
				<div className="row col-12 d-flex justify-content-center text-white">
					<div className="col-md-3 col-xs-9"><img className="logo-inner" src={logo} /></div>
					<div className="col-md-8">&nbsp;</div>
					<div className="col-md-1 col-xs-3"><img className="logo-exl" src={logoexl} /></div>
				</div>
			</nav>


			<Router>
			<Switch> 
		

			<Route path="/manager/managerlanding" component={Managerlanding}></Route>

			<Route path="/manager/managervalidate" component={Managervalidate}></Route>

			<Redirect from="/manager" to="/manager/managerlanding" />
			</Switch>
			</Router>

			<div class="clear"></div>





		</div>



	)
}