import React, { useState, useEffect, useRef } from 'react';
import { getUser, removedUserSession, getUserSession, showToaster } from "../Utils/common";
import { BrowserRouter as Router, Link } from 'react-router-dom';
import { Modal, Button } from 'react-bootstrap';
import { Helmet } from "react-helmet";
// import $ from "jquery";
import pdfFunction from './pdffuction';
import formFunction from './formFunction';
import deleteForm from './deleteForm';
import { ToastContainer, toast } from 'react-toastify';
import info from '../../images/info.png';
import 'react-toastify/dist/ReactToastify.min.css';
import clearFormsFunction from '../Utils/clear_forms';
// import { formvalidation } from './formvalidation';


export default function ManagerValidate(props) {

	<Helmet>
		<script src="./js/custom-pdf.js" type="text/javascript" />
	</Helmet>
	const session = getUserSession()
	if (session == null) {
		props.history.push('/');
	}
	// console.log("Session : " + session)
	const [documentLink, setDocumentLink] = useState(false);
	const setDocumentLinkFunction = (link) => setDocumentLink(link);
	const [show, setShow] = useState(false);
	const handleClose = () => setShow(false);
	const handleShow = () => setShow(true);

	const [showMissingInfo, setShowMissingInfo] = useState(false);
	const handleCloseMissingInfo = () => setShowMissingInfo(false);
	const handleShowMissingInfo = () => setShowMissingInfo(true);

	const [showRejected, setShowRejected] = useState(false);
	const handleCloseRejected = () => setShowRejected(false);
	const handleShowRejected = () => setShowRejected(true);

	const childRef = useRef(null);
	const [open, setOpen] = useState(false);
	const user = getUser();
	const [loading, setLoading] = useState(false);
	const [paykind_code1, setPaykind_code1] = useState('');
	const [paykind_code2, setPaykind_code2] = useState('');
	const [paykind_code3, setPaykind_code3] = useState('');
	const [valid, setValid] = useState('');
	const [sub, setSub] = useState('');
	const [servicestate, setServicestate] = useState('');
	const [claimnumber, setClaimnumber] = useState('');
	const [invoiceno, setInvoiceno] = useState('');
	const [firstname, setFirstname] = useState('');
	const [lastname, setLastname] = useState('');
	const [specialinstructions, setSpecialinstructions] = useState('');
	const [dateofservice1, setDateofservice1] = useState('');
	const [dateofservice2, setDateofservice2] = useState('');
	const [taxid, setTaxid] = useState('');
	const [payeename, setPayeename] = useState('');
	const [mcse, setMcse] = useState('');
	const [address1, setAddress1] = useState('');
	const [address2, setAddress2] = useState('');
	const [cityname, setCityname] = useState('');
	const [zipcode, setZipcode] = useState('');
	const [state, setState] = useState('');
	const [operator_comment, setOperator_comment] = useState('');
	const [natureofpayment, setNatureofpayment] = useState('');
	const [taxable, setTaxable] = useState('');
	const [payableamount, setPayableamount] = useState('');
	const [taxableto, setTaxableto] = useState('');
	const [closeclaim, setCloseclaim] = useState('');
	const [pay_stamp, setPay_stamp] = useState('');
	const [successMessage, setSuccessMessage] = React.useState("");
	const [currentFile, setCurrentFile] = React.useState("");

	const handleLogout = () => {
		removedUserSession();
		props.history.push('/');
	}
	console.log("managervalidte")


	async function GetFile(is_file) {

		// console.log("inside Manager validate, get file")
		// console.log(props.location.state.file)
		let body = {};
		if (is_file) {
			setCurrentFile(props.location.state.file);
			body = {
				"case_id": props.location.state.file
			}
		}
		const response = await fetch(process.env.REACT_APP_API_URL + "/api/get_file/", {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			body: JSON.stringify(body)
		}).then(response => response.json())
			.then(data => {
				// setDocumentLinkFunction(data.data.converted_doc_url);
				if (data.error) {
					showToaster('Next case file is not available for this user,Navigating to home page.', 'error')
					setTimeout(function(){
						{if (data.message == "File not available") {
							props.history.push('/Manager/Managerlanding');
						}
						props.history.push('/Manager/Managerlanding')}
					}, 6000);
					
				}

				// console.log("response")
				let converted_doc = data.data.converted_doc_url;
				let original_doc = data.data.original_doc_url;
				// comment later
				converted_doc = converted_doc.replace("http://10.146.226.17:8002/", "http://localhost:8002/");
				original_doc = original_doc.replace("http://10.146.226.17:8002/", "http://localhost:8002/")
				if (true) {
					setCurrentFile(converted_doc.split("/").slice(-1)[0].split(".")[0])
				}
				//var case_id ={props : {location : {state : { file : data.data.default_json.case_id}}}}
				props.location.state.file = data.data.default_json.case_id ;
				// console.log("fileid------------------------>"+ props.location.state.file);
                setCurrentFile(props.location.state.file)

				pdfFunction(converted_doc, original_doc);
				formFunction(data.data.default_json.extracted_json);

			}).catch(error => {
				// console.log("catch")
				// console.log(error);
			});
	}

	useEffect(() => {

		setTimeout(function(){
			if (localStorage.getItem("pdfName") != null) {
				GetFile(true);
			}
			else {
				GetFile(false);
			}
		}, 500);
	}, []);



	const handleValidateform = async (submitType) => {

		handleClose();
		handleCloseMissingInfo();
		let extracted_json = {};
		let count = 0;
		let api_key = "";
		if (submitType == "submit"  || submitType == "missingInfo" || submitType == "rejected") {
			api_key = process.env.REACT_APP_API_URL + "/api/save_file/";
		} else if (submitType == "draft") {
			api_key = process.env.REACT_APP_API_URL + "/api/save_as_draft/";
		} else {
			api_key = process.env.REACT_APP_API_URL + "/api/save_as_review/";
		}
		let is_numeric = /^\d+$/;
		let is_amount = /^[+-]?[0-9]{1,3}(?:,?[0-9]{3})*\.[0-9]{2}$/;
		let is_alpha = /^[a-zA-Z ]*$/;
		var date_regex = /^\d{2}\/\d{2}\/\d{2}$/;
		let is_date = /^(Jan(uary)?|Feb(ruary)?|Mar(ch)?|Apr(il)?|May|Jun(e)?|Jul(y)?|Aug(ust)?|Sep(tember)?|Oct(ober)?|Nov(ember)?|Dec(ember)?)\s+\d{1,2},\s+\d{4}/;
		let is_taxid = /^[0-9 \-]+$/;
		let is_zipcode = /^(\d{5}(?:\-\d{4})?)$/;
		let is_claim = /^[0-9]{10,10}$/;
		while (true) {
			// let form = {};

			if (document.getElementById("paykind_code1" + count) != null) {
				// if (submitType != "draft" )
				if (submitType == "submit") {
					// if (document.getElementById("paykind_code1" + count).value && !is_numeric.test( document.getElementById("paykind_code1" + count).value)) {
					// 	showToaster('Enter Paykind Code in Numeric only', 'info')
					// 	document.getElementById("paykind_code1" + count).focus()
					// 	return
					// } 
					// if (document.getElementById("paykind_code2" + count).value && !is_numeric.test( document.getElementById("paykind_code2" + count).value)) {
					// 	showToaster('Enter Paykind Code in Numeric only', 'info')
					// 	document.getElementById("paykind_code2" + count).focus()
					// 	return
					// } 
					// if (document.getElementById("paykind_code3" + count).value && !is_numeric.test( document.getElementById("paykind_code3" + count).value)) {
					// 	showToaster('Enter Paykind Code in Numeric only', 'info')
					// 	document.getElementById("paykind_code3" + count).focus()
					// 	return
					// } 
					// if (document.getElementById("pay_stamp" + count).value && !is_date.test(document.getElementById("pay_stamp" + count).value)) {
					// 	showToaster('Please enter OK to Pay Stamp', 'info')
					// 	document.getElementById("pay_stamp" + count).focus()
					// 	return
					// }					
					
					if (document.getElementById("sub" + count).value && !is_numeric.test(document.getElementById("sub" + count).value)) {
						showToaster('Enter Sub in Numeric only', 'info')
						document.getElementById("sub" + count).focus()
						return
					}
					if (document.getElementById("valid1" + count).value && !is_alpha.test(document.getElementById("valid1" + count).value)) {
						showToaster('Enter correct Val ID 1', 'info')
						document.getElementById("valid1" + count).focus()
						return
					}
					if (document.getElementById("valid2" + count).value && !is_alpha.test(document.getElementById("valid2" + count).value)) {
						showToaster('Enter correct Val ID 2', 'info')
						document.getElementById("valid2" + count).focus()
						return
					}
					if (document.getElementById("servicestate" + count).value && !is_alpha.test(document.getElementById("servicestate" + count).value)) {
						showToaster('Enter correct Service State', 'info')
						document.getElementById("servicestate" + count).focus()
						return
					}
					if (document.getElementById("claimnumber" + count).value && !is_claim.test(document.getElementById("claimnumber" + count).value)) {
						showToaster('Enter Claim Number in 10 digit Numeric only', 'info')
						document.getElementById("claimnumber" + count).focus()
						return
					}
					// if (document.getElementById("firstname" + count).value && !is_alpha.test(document.getElementById("firstname" + count).value)) {
					// 	showToaster('Please enter correct First Name', 'info')
					// 	document.getElementById("firstname" + count).focus()
					// 	return
					// }
					// if (document.getElementById("lastname" + count).value && !is_alpha.test(document.getElementById("lastname" + count).value)) {
					// 	showToaster('Please enter correct Last Name', 'info')
					// 	document.getElementById("lastname" + count).focus()
					// 	return
					// }
					// if (document.getElementById("invoiceno" + count).value && !is_numeric.test(document.getElementById("invoiceno" + count).value)) {
					// 	showToaster('Enter Invoice No in Numeric only', 'info')
					// 	document.getElementById("invoiceno" + count).focus()
					// 	return
					// }

					if (document.getElementById("payableamount1" + count).value == '') {
						showToaster('Payable amount cannot be empty', 'info')
						document.getElementById("payableamount1" + count).focus()
						return
					}
					if (!is_amount.test(document.getElementById("payableamount1" + count).value)) {
						showToaster('Enter Total payable amount in correct format (.00)', 'info')
						document.getElementById("payableamount1" + count).focus()
						return
					}
					if (document.getElementById("dateofservice1" + count).value == '') {
						showToaster('Date of service cannot be empty', 'info')
						document.getElementById("dateofservice1" + count).focus()
						return
					}
					if (!date_regex.test(document.getElementById("dateofservice1" + count).value)) {
						showToaster('Enter Date in mm/dd/yy format', 'info')
						document.getElementById("dateofservice1" + count).focus()
						return
					}
					if (document.getElementById("dateofservice2" + count).value == '') {
						showToaster('Date of service cannot be empty', 'info')
						document.getElementById("dateofservice2" + count).focus()
						return
					}
					if (!date_regex.test(document.getElementById("dateofservice2" + count).value)) {
						showToaster('Enter Date in mm/dd/yy format', 'info')
						document.getElementById("dateofservice2" + count).focus()
						return
					}




					if (document.getElementById("taxid" + count).value && !is_taxid.test(document.getElementById("taxid" + count).value)) {
						showToaster('Enter Tax ID in Numeric only', 'info')
						document.getElementById("taxid" + count).focus()
						return
					}
					if (document.getElementById("payeename" + count).value == '') {
						showToaster('Payee Name cannot be empty', 'info')
						document.getElementById("payeename" + count).focus()
						return
					}
					// if (!is_alpha.test(document.getElementById("payeename" + count).value)) {
					// 	showToaster('Please enter correct Payee Name', 'info')
					// 	document.getElementById("payeename" + count).focus()
					// 	return
					// }
					// if (document.getElementById("mailtoname" + count).value && !is_alpha.test(document.getElementById("mailtoname" + count).value)) {
					// 	showToaster('Enter Correct Mail To Name', 'info')
					// 	document.getElementById("mailtoname" + count).focus()
					// 	return
					// }
					// if (document.getElementById("mailtoname" + count).value == document.getElementById("payeename" + count).value) {
					// 	showToaster('Mail to name and Payee Name can not be same', 'info')
					// 	document.getElementById("payeename" + count).focus()
					// 	return
					// }
					// if (document.getElementById("address1" + count).value == '') {
					// 	showToaster('Address  cannot be empty', 'info')
					// 	document.getElementById("address1" + count).focus()
					// 	return
					// }
					// if (document.getElementById("cityname" + count).value == '') {
					// 	showToaster('City Name  cannot be empty', 'info')
					// 	document.getElementById("cityname" + count).focus()
					// 	return
					// }
					if (!is_alpha.test(document.getElementById("cityname" + count).value)) {
						showToaster('Please enter correct City Name', 'info')
						document.getElementById("cityname" + count).focus()
						return
					}
					// if (document.getElementById("zipcode" + count).value == '') {
					// 	showToaster('Zip code  cannot be empty', 'info')
					// 	document.getElementById("zipcode" + count).focus()
					// 	return
					// }
					if ( document.getElementById("zipcode" + count).value && !is_zipcode.test(document.getElementById("zipcode" + count).value)) {
						showToaster('Please enter correct Zip code', 'info')
						document.getElementById("zipcode" + count).focus()
						return
					}

					// if (document.getElementById("state" + count).value == '') {
					// 	showToaster('State  cannot be empty', 'info')
					// 	document.getElementById("state" + count).focus()
					// 	return
					// }
					if (!is_alpha.test(document.getElementById("state" + count).value)) {
						showToaster('Please enter correct State', 'info')
						document.getElementById("state" + count).focus()
						return
					}

					var dateFrom = document.getElementById("dateofservice1" + count).value.trim()
					var dateTo = document.getElementById("dateofservice2" + count).value.trim()
					dateFrom = new Date(dateFrom);
					dateTo = new Date(dateTo);
					if (dateFrom - dateTo > 0) {
						showToaster('To date must be greater than from date', 'info')
						document.getElementById("dateofservice1" + count).focus()
						return
					}

					// if (document.getElementById("natureofpayment" + count).value && !is_alpha.test( document.getElementById("natureofpayment" + count).value)) {
					// 	showToaster('Please enter correct Nature of payment', 'info')
					// 	document.getElementById("natureofpayment" + count).focus()
					// 	return
					// } 
					if (document.getElementById("PageNo" + count).value == '') {
						showToaster('Page no. to apply Paid Stamp cannot be empty', 'info')
						document.getElementById("PageNo" + count).focus()
						return
					}
					if (document.getElementById("PageNo" + count).value && !is_numeric.test(document.getElementById("PageNo" + count).value)) {
						showToaster('Enter Page no. to apply Paid Stamp in Numeric only', 'info')
						document.getElementById("PageNo" + count).focus()
						return
					}

				}


				let form_data = {
					pay_stamp: document.getElementById("pay_stamp" + count).value,					
					paykind_code1: document.getElementById("paykind_code1" + count).value,
					paykind_code2: document.getElementById("paykind_code2" + count).value,
					paykind_code3: document.getElementById("paykind_code3" + count).value,
					valid: document.getElementById("valid1" + count).value,
					valid2: document.getElementById("valid2" + count).value,
					sub: document.getElementById("sub" + count).value,
					servicestate: document.getElementById("servicestate" + count).value,
					claimnumber: document.getElementById("claimnumber" + count).value,
					invoiceno: document.getElementById("invoiceno" + count).value,
					firstname: document.getElementById("firstname" + count).value,
					lastname: document.getElementById("lastname" + count).value,
					specialinstructions1: document.getElementById("specialinstructions1" + count).value,
					specialinstructions2: document.getElementById("specialinstructions2" + count).value,
					closeclaim: document.getElementById("closeclaim" + count).value,
					totalpayableamountpaykindcode1: document.getElementById("payableamount1" + count).value,
					totalpayableamountpaykindcode2: document.getElementById("payableamount2" + count).value,
					dateofservice1: document.getElementById("dateofservice1" + count).value,
					dateofservice2: document.getElementById("dateofservice2" + count).value,
					taxid: document.getElementById("taxid" + count).value,
					payeename: document.getElementById("payeename" + count).value,
					mailtoname: document.getElementById("mailtoname" + count).value,
					address1: document.getElementById("address1" + count).value,
					address2: document.getElementById("address2" + count).value,
					cityname: document.getElementById("cityname" + count).value,
					zipcode: document.getElementById("zipcode" + count).value,
					state: document.getElementById("state" + count).value,
					PageNo: document.getElementById("PageNo" + count).value,
					natureofpayment: document.getElementById("natureofpayment" + count).value,
					1099: document.getElementById("taxable" + count).value,
					taxableto: document.getElementById("taxableto" + count).value,
					mcsc: document.getElementById("mcsc" + count).value,
					settlementCodePaykindCode1: document.getElementById("settlement_code1" + count).value,
					settlementCodePaykindCode2: document.getElementById("settlement_code2" + count).value,
					
					


				}
				extracted_json['form' + count] = form_data
				count++;
			} else {
				break
			}

		}

		// console.log(extracted_json)
		//return
		let comment = "";
		if (document.getElementById("review") != null) {
			comment = document.getElementById("review").value;
		}

		let missingInfo = false;
		if (submitType == "missingInfo") {
			missingInfo = true;
		}

		let isRejected = false;
		if (submitType == "rejected") {
		
			isRejected = true;
		}
		const response = await fetch(api_key, {
			method: "POST",
			mode: "cors",
			headers: {
				"Content-Type": "application/json",
				"Access-Control-Allow-Origin": "*",
				"Access-Control-Allow-Headers": "*",
				"Access-Control-Allow-Methods": "*",
				"Access-Control-Expose-Headers": "*",
				"Access-Control-Allow-Credentials": false,
				"Authorization": "Bearer " + getUserSession()
			},
			body: JSON.stringify({
				"data": {
					"case_id": props.location.state.file,
					"extracted_json": {
						"case_id": props.location.state.file,
						"extracted_json": extracted_json,
						"comment": comment,
						"multiclaim": document.getElementById("multiple_claim").checked,
						"missingInfo": missingInfo
					},
					"rush_case": document.getElementById("rush_case").checked,
					"comment": comment,
					"rejected" : isRejected

					// ,priority: 0

				}
			})
		}).then(response => response.json())
			.then(data => {
				// console.log("response")
				// console.log(data)
				setLoading(false);
				if (data.error === true) {
					if (typeof data.message === 'string') {
						showToaster(data.message, 'error')
					}
					else{
						for (var i in data.message) {
							showToaster(data.message[i][0], 'error')
					
							
						}
					}
					  
				}
				else {
					// setSuccessMessage(data.message)
					showToaster(data.message + " for case -" + currentFile, 'success');
					if (submitType != "draft") {
						localStorage.removeItem("pdfName");
						window.location.reload()
						// clearFormsFunction(count);
						// document.getElementById("delete_btn").click();
						// deleteForm(extracted_json);
						// document.getElementById("multiple_claim").checked = false;
						// document.getElementById("rush_case").checked = false;
						// GetFile(false);
						// count = 0;


					}

				}


			}).catch(error => {
				// console.log("catch")
				// console.log(error)
				setLoading(false);
				showToaster('Something went wrong', 'error')
			});

	}

	return (

		<div className="">
			{/* <Modal show={show} onHide={handleClose}>
				<Modal.Header closeButton>
					Send for review
				</Modal.Header>
				<Modal.Body><textarea id="review" class="form-control" placeholder='Enter your review
' name="review" rows="4" cols="50">
				</textarea></Modal.Body>
				<Modal.Footer>

					<Button variant="warning" onClick={() => handleValidateform("review")}>
						Submit Review
					</Button>
				</Modal.Footer>
			</Modal> */}

<Modal show={showMissingInfo} onHide={handleCloseMissingInfo}>
				<Modal.Header closeButton>
					Send for review
				</Modal.Header>
				<Modal.Body>
					<p>Are you sure this case has missing information?</p>
				</Modal.Body>
				<Modal.Footer>

					<Button variant="warning" onClick={() => handleValidateform("missingInfo")}>
						Yes
					</Button>
					<Button variant="warning" onClick={() => handleCloseMissingInfo()}>
						No
					</Button>
				</Modal.Footer>
			</Modal>
			<Modal show={showRejected} onHide={handleCloseRejected}>
				<Modal.Header closeButton>
					Reject File ?.
				</Modal.Header>
				<Modal.Body>
					<p>Are you sure want to reject this file?</p>
				</Modal.Body>
				<Modal.Footer>

					<Button variant="warning" onClick={() => handleValidateform("rejected")}>
						Yes
					</Button>
					<Button variant="warning" onClick={() => handleCloseRejected()}>
						No
					</Button>
				</Modal.Footer>
			</Modal>

			<div className="row py-4">
				<div className='col-md-7'><Link className=" back" to={'/Manager/Managerlanding'}></Link> <div className="optcase-id"> Case ID - {currentFile}</div> </div>

				<div className="col-md-5"><a href="" type="link" className="logout" onClick={handleLogout}>Logout</a></div>

			</div>

			<div className="row">
			<div className=" col-md-7" >
					<div className="row">
					<div class="wrap">
<div class="but"><img src={info} style={{ height: '32px' }} alt="" /></div>
<div class="content">{operator_comment}</div>
</div>
						
					</div>
				</div>
				<div className="col-md-5 row">
					<div className="col-md-7 row">

						<div className="col-md-6 py-2">

							<label className='col-8'>Rush case</label>
							<input type="checkbox" className='col-2' id="rush_case" name="Rush cases" ></input>

						</div>
						<div className="col-md-6 py-2">
							<label className='col-9'>Multiple Claim</label>
							<input type="checkbox" className='col-2' id="multiple_claim" name="Multiple Claim" ></input>

						</div>

					</div>
					<div className="col-md-5">
						<button type="button" class="btn btn-outline-warning add-form ms-2 d-flex flex-row justify-content-end" id="addform">+ Add form</button></div>

				</div>
			</div>
			<div className="row  scroll-box">
				<div className="col-md-7 padding-right0" >

					<div className='pdf-container'>

						<div class="col" >



						</div>
						<div class="row pdf-head justify-content-between">
							<div class=" col-2 d-flex flex-row justify-content-start">
								<button type="button" class="btn btn-warning pdf-button" id="prev">Previous</button>
							</div>
								
							<div class=" col-3">
								<button id='zoomOut' class="btn btn-warning pdf-button" style={{width:"30px", marginRight:"10px"}}> - </button>
								<span>Page: <span id="page_num"></span> / <span id="page_count"></span></span>
								<button id='zoomIn' class="btn btn-warning pdf-button" style={{width:"30px", marginLeft:"10px"}}> + </button>
							</div>
							
							<div class=" col-2 d-flex flex-row justify-content-end">
								<button type="button" class="btn btn-warning pdf-button" id="next">Next</button>
							</div>


						</div>
						<p id="errorPdf" style={{ display: "none", color: "red" }}>Error in loading PDF. Send this file for review.</p>
						
						<div className='overflow' id="pdfcontainer">
						<div><canvas id="the-canvas"></canvas></div>
							<div class="textLayer" id='textLayer'></div>
							
						</div>




						{/* <MyComponent state={documentLink} /> */}
						{/* <embed src="http://localhost:8000/expense/_1340049686.pdf" width="800px" height="2100px" /> */}
					</div>
				</div>
				<div className="col-md-5 padding-left0 form-height" >
					<div id='formId'>
						<button class="active accordion" id="accordionBtn1">Details to be Filled</button>
						<div class="panel" id="panel" style={{ display: "block" }} >

							<div className="row"  >
								{successMessage && <div className="success"> {successMessage} </div>}

								<div className="col-md-6">
									<div className="form-group">
										<label >OK to Pay Stamp</label>
										<input type="text" className="form-control" id="pay_stamp0" />
										{/* <select class="form-select" id="pay_stamp0">
											<option value="Yes" selected>Yes</option>
											<option value="No" >No</option>

										</select> */}
										{/* <input type="text" className="form-control"  /> */}
									</div>
								</div>
								
								<div className="col-md-6" id='fieldId'>
									<div className="form-group">
										<label htmlFor="Paykind_code">Paykind code 1</label>
										<input type="text" className="form-control" id="paykind_code10" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Paykind_code">Paykind code 2</label>
										<input type="text" className="form-control" id="paykind_code20" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Paykind_code">Paykind code 3</label>
										<input type="text" className="form-control" id="paykind_code30" />
									</div>
								</div>								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Sub">Sub#</label>
										<input type="text" maxlength="3" className="form-control" id="sub0" />
										<div id="alert_sub0" className='message' style={{ display: "none" }} >Sub value should be in 3 digits. By default value is 001</div>
									</div>

								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="settlement_code">Settlement Code-Paykind Code 1</label>
										<input type="text" className="form-control" id="settlement_code10" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="settlement_code">Settlement Code-Paykind Code 2</label>
										<input type="text" className="form-control" id="settlement_code20" />
										</div>

								</div>

								
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Val_ID">Val ID 1</label>
										<input type="text" className="form-control" id="valid10" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Val_ID">Val ID 2</label>
										<input type="text" className="form-control" id="valid20" />
									</div>
								</div>

								<button id='delete_btn' style={{visibility:"hidden"}}></button>
								<div className="col-md-6">
									<div className="form-group">

										<label htmlFor="">Service State</label>
										<select name="state" class="form-select" value={servicestate} onChange={e => setServicestate(e.target.value)} id="servicestate0">
										<option value="" selected>Select service state</option>
											<option value="AL" >AL</option>
											<option value="AK">AK</option>
											<option value="AZ">AZ</option>
											<option value="AR">AR</option>
											<option value="CA">CA</option>
											<option value="CO">CO</option>
											<option value="CT">CT</option>
											<option value="DE">DE</option>
											<option value="DC">DC</option>
											<option value="FL">FL</option>
											<option value="GA">GA</option>
											<option value="HI">HI</option>
											<option value="ID">ID</option>
											<option value="IL">IL</option>
											<option value="IN">IN</option>
											<option value="IA">IA</option>
											<option value="KS">KS</option>
											<option value="KY">KY</option>
											<option value="LA">LA</option>
											<option value="ME">ME</option>
											<option value="MD">MD</option>
											<option value="MA">MA</option>
											<option value="MI">MI</option>
											<option value="MN">MN</option>
											<option value="MS">MS</option>
											<option value="MO">MO</option>
											<option value="MT">MT</option>
											<option value="NE">NE</option>
											<option value="NV">NV</option>
											<option value="NH">NH</option>
											<option value="NJ">NJ</option>
											<option value="NM">NM</option>
											<option value="NY">NY</option>
											<option value="NC">NC</option>
											<option value="ND">ND</option>
											<option value="OH">OH</option>
											<option value="OK">OK</option>
											<option value="OR">OR</option>
											<option value="PA">PA</option>
											<option value="RI">RI</option>
											<option value="SC">SC</option>
											<option value="SD">SD</option>
											<option value="TN">TN</option>
											<option value="TX">TX</option>
											<option value="UT">UT</option>
											<option value="VT">VT</option>
											<option value="VA">VA</option>
											<option value="WA">WA</option>
											<option value="WV">WV</option>
											<option value="WI">WI</option>
											<option value="WY">WY</option>
										</select>
										{/* <input type="text" maxlength="2" className="form-control" id="servicestate0" /> */}
										{/* <div id="alert_servicestate0" className='message' style={{ display: "none" }} >Service state should be 2 character alpha </div> */}
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">

										<label htmlFor="ClaimNumber">Claim Number</label>
										<input type="text" maxlength="10" className="form-control" id="claimnumber0" />
										<div id="alert_claimnumber0" className='message' style={{ display: "none" }} >Claim number should be in 10 digits</div>
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Requestor First name</label>
										<input type="text" className="form-control" id="firstname0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Requestor Last name</label>
										<input type="text" className="form-control" id="lastname0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label>Invoice No</label>
										<input type="text" className="form-control" id="invoiceno0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Close Claim</label>
										<select class="form-select" value={closeclaim} onChange={e => setCloseclaim(e.target.value)} id="closeclaim0">
											<option value="Yes" >Yes</option>
											<option value="No" selected>No</option>

										</select>

									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Specialinstructions">Special instructions 1</label>
										<input type="text" className="form-control" id="specialinstructions10" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="Specialinstructions">Special instructions 2</label>
										<input type="text" className="form-control" id="specialinstructions20" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">

										<label htmlFor="">Total payable amount_paykind code 1 <span className='star'>*</span></label>
										<input type="text" required className="form-control" id="payableamount10" />
										<div id="alert_payable10" className='message' style={{ display: "none" }} >Payable amount can not be more than 1 million</div>
									</div>

								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Total payable amount_paykind code 2 </label>
										<input type="text" required className="form-control" id="payableamount20" />
										<div id="alert_payable20" className='message' style={{ display: "none" }} >Payable amount can not be more than 1 million</div>
									</div>
								</div>


								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Date of service<span className='star'>*</span></label>
										<input type="text" className="form-control" placeholder='From' id="dateofservice10" />
										<div id="alert_dateofservice10" className='message' style={{ display: "none" }} >Enter Date of service mm/dd/yy format</div>
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">&nbsp;</label>
										<input type="text" className="form-control" placeholder='To' id="dateofservice20" />
										<div id="alert_dateofservice20" className='message' style={{ display: "none" }} >Enter Date of service mm/dd/yy format</div>
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">

										<label htmlFor="">Tax ID </label>
										<input type="text" maxlength="9" required className="form-control" id="taxid0" />
										<div id="alert_taxid0" className='message' style={{ display: "none" }} >Tax ID should be in 9 digits</div>
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Payee Name<span className='star'>*</span></label>
										<input type="text" className="form-control" id="payeename0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Mail To Name</label>
										<input type="text" className="form-control" id="mailtoname0" />
									</div>
								</div>

								{/* <div className="col-md-6">
									<div className="form-group">
										<label htmlFor=""></label>
										<input type="text" className="form-control" id="remitto0" />
									</div>
								</div> */}
								<div className="col-md-6">
									<div className="form-group">
										<label >Address/Remit To (Line 1)<span className='star'></span></label>
										<input type="text" className="form-control" id="address10" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Address/Remit To (Line 2)</label>
										<input type="text" className="form-control" id="address20" />
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">City Name<span className='star'></span></label>
										<input type="text" className="form-control" id="cityname0" />
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">

										<label htmlFor="">Zip Code<span className='star'></span></label>
										<input type="text"  className="form-control" id="zipcode0" />
										{/* <div id="alert_zipcode0" className='message' style={{ display: "none" }} >Zip code should be in 5 digit only</div> */}
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">State<span className='star'></span></label>										
										<select name="state" class="form-select" value={state} onChange={e => setState(e.target.value)} id="state0">
										<option value="" selected>Select state</option>
											<option value="AL" >AL</option>
											<option value="AK">AK</option>
											<option value="AZ">AZ</option>
											<option value="AR">AR</option>
											<option value="CA">CA</option>
											<option value="CO">CO</option>
											<option value="CT">CT</option>
											<option value="DE">DE</option>
											<option value="DC">DC</option>
											<option value="FL">FL</option>
											<option value="GA">GA</option>
											<option value="HI">HI</option>
											<option value="ID">ID</option>
											<option value="IL">IL</option>
											<option value="IN">IN</option>
											<option value="IA">IA</option>
											<option value="KS">KS</option>
											<option value="KY">KY</option>
											<option value="LA">LA</option>
											<option value="ME">ME</option>
											<option value="MD">MD</option>
											<option value="MA">MA</option>
											<option value="MI">MI</option>
											<option value="MN">MN</option>
											<option value="MS">MS</option>
											<option value="MO">MO</option>
											<option value="MT">MT</option>
											<option value="NE">NE</option>
											<option value="NV">NV</option>
											<option value="NH">NH</option>
											<option value="NJ">NJ</option>
											<option value="NM">NM</option>
											<option value="NY">NY</option>
											<option value="NC">NC</option>
											<option value="ND">ND</option>
											<option value="OH">OH</option>
											<option value="OK">OK</option>
											<option value="OR">OR</option>
											<option value="PA">PA</option>
											<option value="RI">RI</option>
											<option value="SC">SC</option>
											<option value="SD">SD</option>
											<option value="TN">TN</option>
											<option value="TX">TX</option>
											<option value="UT">UT</option>
											<option value="VT">VT</option>
											<option value="VA">VA</option>
											<option value="WA">WA</option>
											<option value="WV">WV</option>
											<option value="WI">WI</option>
											<option value="WY">WY</option>
										</select>
										{/* <div id="alert_state0" className='message' style={{ display: "none" }} >State should be in 2 alpha character</div> */}
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label >Page no to apply Paid Stamp<span className='star'>*</span></label>
										<input type="text" className="form-control" id="PageNo0" />										
									</div>
								</div>
								<div className='clear'></div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Nature of Payment</label>
										<input type="text" className="form-control" id="natureofpayment0" />
									</div>								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">1099</label>
										<select class="form-select" value={taxable} onChange={e => setTaxable(e.target.value)} id="taxable0">
											<option value="Yes" >Yes</option>
											<option value="No" selected>No</option>

										</select>
									</div>
								</div>

								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">Taxable To</label>
										<select class="form-select" value={taxableto} onChange={e => setTaxableto(e.target.value)} id="taxableto0">
											<option value="">Select</option>
											<option value="A">A- Attorney</option>
											<option value="B">B- Both (Attorney + Claimaint)</option>
											<option value="C">C- Claimaint</option>
											<option value="V" selected>V- Vendor</option>

										</select>
									</div>
								</div>
								<div className="col-md-6">
									<div className="form-group">
										<label htmlFor="">MCSC/MBR</label>
										<select class="form-select" id="mcsc0">
											<option value="Yes" >Yes</option>
											<option value="No" selected>No</option>

										</select>
									</div>
								</div>
							</div>

						</div>
					</div>
				</div>
			</div>
			<div style={{ visibility: 'hidden' }}>
				<div class="button-center d-flex justify-content-center btn-group" role="group" aria-label="Basic radio toggle button group" id="groupid">
					<input type="radio" class="btn-check" name="btnradio" id="btnradio1" autocomplete="off" />
					<label class="btn btn-outline-warning" style={{ width: '150px' }} for="btnradio1">Orginal</label>

					<input type="radio" class="btn-check" name="btnradio" id="btnradio2" autocomplete="off" checked />
					<label class="btn btn-outline-warning" style={{ width: '150px' }} for="btnradio2">Processed</label>
				</div>

			</div>
			<div className="row py-3">
				<div className="col-md-8">


					</div>
				<div className="col-md-4">
					{/* <p>{Post.value}</p> */}
					<Button className="form-group  btn btn-danger "  onClick={() => handleShowRejected()} >Rejected</Button>&nbsp;&nbsp;&nbsp;&nbsp; 
				
					<Button className="form-group  btn btn-danger "  onClick={() => handleShowMissingInfo()} >Missing Information</Button>&nbsp;&nbsp;&nbsp; 
					<input className="form-group  btn btn-warning  sub-button" type="button" value={"Submit"} onClick={() => handleValidateform("submit")} /></div>


			</div>

			<ToastContainer
				position="top-right"
				autoClose={5000}
				hideProgressBar={false}
				newestOnTop={false}
				closeOnClick
				rtl={false}
				pauseOnFocusLoss
				draggable
				pauseOnHover
				theme='colored' />

		</div>



	)
}

